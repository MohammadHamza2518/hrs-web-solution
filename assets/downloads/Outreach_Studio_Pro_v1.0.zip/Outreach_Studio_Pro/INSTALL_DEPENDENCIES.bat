@echo off
title Install Dependencies - Outreach Studio Pro
cd /d "%~dp0"
color 0a

echo =======================================================================
echo   OUTREACH STUDIO PRO — DEPENDENCY INSTALLER
echo =======================================================================
echo.
echo Installing required Python packages (Flask, Requests, xlsxwriter, etc.)...
echo.

set "PY_CMD=python"
where python >nul 2>nul
if %errorlevel% neq 0 (
    where py >nul 2>nul
    if %errorlevel% equ 0 (
        set "PY_CMD=py"
    ) else (
        color 0c
        echo [ERROR] Python not found! Please install Python 3.x with PATH enabled.
        pause
        exit /b 1
    )
)

%PY_CMD% -m pip install --upgrade pip
%PY_CMD% -m pip install -r requirements.txt

echo.
echo =======================================================================
echo [SUCCESS] All dependencies installed successfully!
echo You can now double-click 'LAUNCH_GLOBAL_OUTREACH_STUDIO.bat' to start.
echo =======================================================================
echo.
pause
