# 🚀 Web Agency Automated Lead Generation & Outreach Engine

Ek end-to-end automated software jo Google Maps aur social platforms se aise high-potential businesses filter karta hai jinki **Official Website nahi hai**, unke phone numbers extract karta hai, aur unke liye **"Free Custom Demo"** offer ke sath high-converting personalized WhatsApp messages bhejta hai.

> 📖 **Daily Workflow Rules & SOP:** Read [DAILY_LEAD_GENERATION_SOP.md](DAILY_LEAD_GENERATION_SOP.md) for strict rules (Daily 15 owner mobiles, Zero landlines, Verified no-website, Free demo copy).

---

## 📂 Project Structure

```
atumations/
├── config.py              # Niches, cities, search presets, pitch templates, safety limits
├── scraper.py             # Playwright Google Maps Scraper (Filters: Has_Website == False)
├── pitch_generator.py     # Psychology-backed pitch generator (Praise + Why Website + Free Demo)
├── crm_manager.py         # SQLite DB + Styled Excel CRM exporter (leads_crm.xlsx)
├── whatsapp_sender.py     # Safe WhatsApp Web automated sender (Anti-ban delays + Session save)
├── main.py                # Single-click master runner & CLI
├── README.md              # Documentation & usage guide
└── data/
    ├── leads.db           # SQLite database storing all discovered leads & outreach status
    ├── leads_crm.xlsx     # Formatted Excel sheet with color badges
    ├── leads_dashboard.html # Interactive browser UI with 1-Click WhatsApp buttons
    └── whatsapp_session/  # Persistent browser profile (QR login saved permanently)
```

---

## ⚡ Quick Start Guide

### 1. Interactive Menu Run Karein
Terminal / CMD me type karein:
```bash
python main.py
```
Aapke samne ek interactive menu khulega:
* **Option 1:** Google Maps se kisi bhi Niche & City ke leads scrape karein.
* **Option 2:** New leads ke liye AI Pitch generate karein.
* **Option 3:** Clean Excel CRM (`leads_crm.xlsx`) generate karein.
* **Option 4:** Interactive HTML Dashboard (`leads_dashboard.html`) open karein.
* **Option 5:** Safe WhatsApp outreach launch karein.
* **Option 6:** Full automatic pipeline (Scrape -> Filter -> Pitch -> Excel -> Dashboard).

---

## 🎯 Command Line Shortcuts (Direct Commands)

### 🔍 Google Maps se Leads Dhoondhna:
```bash
# Specific query aur count ke sath
python main.py --action scrape --query "Dental Clinic in Gurgaon" --max 10
python main.py --action scrape --query "Luxury Salon in South Delhi" --max 10
python main.py --action scrape --query "Interior Designer in Noida" --max 10
```

### 📊 Excel CRM & HTML Dashboard Update Karna:
```bash
python main.py --action export
python main.py --action dashboard
```

### 💬 WhatsApp Outreach Launch Karna:
```bash
# Test Mode (Bina message send kiye screen par preview karega):
python main.py --action outreach --max 5 --test

# Live Mode (Automated send with 45-85s anti-ban delays):
python main.py --action outreach --max 10
```

---

## 🛡️ Anti-Ban Safety Rules (WhatsApp Protection)

1. **Random Human Delays:** Har message ke beech 45 se 85 seconds ka random gap hota hai taaki WhatsApp ko robot activity na lage.
2. **Session Persistence:** Aapko sirf pehli baar WhatsApp Web QR scan karna hota hai. Uske baad session `data/whatsapp_session` me permanently save rehta hai.
3. **Daily Limit:** Ek din me ek number se maximum 30–40 messages bhejte hain taaki account 100% safe rahe.
4. **1-Click HTML Dashboard:** Agar aap manually review karke bhejna chahte hain, toh `data/leads_dashboard.html` open karein aur har lead ke samne bane green **"💬 WhatsApp"** button par click karke 1-click me message bhej sakte hain!
