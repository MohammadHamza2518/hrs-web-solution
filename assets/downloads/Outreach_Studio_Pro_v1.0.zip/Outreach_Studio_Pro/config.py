import os

# Base paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "leads.db")
EXCEL_REPORT_PATH = os.path.join(DATA_DIR, "leads_crm.xlsx")
WHATSAPP_SESSION_DIR = os.path.join(DATA_DIR, "whatsapp_session")

# Ensure directories exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(WHATSAPP_SESSION_DIR, exist_ok=True)

# High-Ticket Global Wealth Hubs & Presets (Top Tier-1 Countries)
SEARCH_PRESETS = [
    # 🇨🇭 Switzerland (Zurich, Geneva, Basel, Lausanne - Highest Purchasing Power in the World)
    {"niche": "Luxury Interior Architecture", "city": "Zurich", "country": "Switzerland"},
    {"niche": "Private Dental & Orthodontics", "city": "Geneva", "country": "Switzerland"},
    {"niche": "High-End Home Renovation", "city": "Basel", "country": "Switzerland"},
    {"niche": "Wealth Advisory & Family Office", "city": "Zurich", "country": "Switzerland"},
    {"niche": "Aesthetic & Cosmetic Clinic", "city": "Lausanne", "country": "Switzerland"},
    {"niche": "Luxury Auto Detailing & Supercars", "city": "Geneva", "country": "Switzerland"},

    # 🇪🇺 Top Tier Europe (Monaco, Luxembourg, Munich, Vienna)
    {"niche": "Private Aesthetic Clinic", "city": "Munich", "country": "Europe"},
    {"niche": "Luxury Architecture & Remodeling", "city": "Vienna", "country": "Europe"},
    {"niche": "Yacht Charter & Luxury Marine", "city": "Monaco", "country": "Europe"},
    {"niche": "Corporate Tax & Wealth Advisory", "city": "Luxembourg", "country": "Europe"},

    # 🇦🇪 UAE & 🇬🇧 UK (High-Ticket Wealth Hubs)
    {"niche": "Cosmetic & Aesthetic Clinic", "city": "Dubai", "country": "UAE"},
    {"niche": "Luxury Villa Interior Design", "city": "Dubai", "country": "UAE"},
    {"niche": "Bespoke Builder & Renovation", "city": "London", "country": "UK"},
    {"niche": "Private Cosmetic Dentist", "city": "Surrey", "country": "UK"},
]

# Anti-Ban Safety Rules (Strict Human Outreach Protocol)
SAFETY_CONFIG = {
    "MIN_DELAY_SECONDS": 45,       # Mandatory minimum wait between messages (45s cooldown)
    "MAX_DELAY_SECONDS": 75,       # Maximum randomized human wait
    "DAILY_MAX_MESSAGES": 15,      # Strict maximum daily outreach limit per WhatsApp number
    "HEADLESS_BROWSER": False,     # Visible browser for human verification & QR scan
}

# Ultra-Short Human Outreach Templates (No sales pitch feel)
PITCH_TEMPLATES = {
    "hinglish_default": (
        "Namaste, quick question for the owner of {business_name}.\n\n"
        "Google Maps par aapka profile dekha {city} me, customer feedback kaafi accha hai.\n\n"
        "Noticed ki profile par website connected nahi hai. Kya aap new clients ke liye website setup karne ka soch rahe hain?\n\n"
        "Maine aapke business ke liye ek quick concept tayyar kiya hai. Agar aap dekhna chahein toh quick demo share karu?\n\n"
        "Hamza"
    ),
    "english_professional": (
        "Hi, quick question for the owner of {business_name}.\n\n"
        "Saw your profile on Google Maps in {city}—great reviews.\n\n"
        "Noticed you do not have a website connected to your listing though. Were you looking to get one set up to bring in more direct clients?\n\n"
        "I put together a quick concept of how it could look for {business_name} if you would like to see it. Mind if I share a quick demo?\n\n"
        "Best,\n"
        "Hamza"
    )
}

