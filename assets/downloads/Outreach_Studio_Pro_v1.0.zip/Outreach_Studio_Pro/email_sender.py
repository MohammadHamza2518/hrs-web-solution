import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from crm_manager import CRMManager

class EmailSender:
    def __init__(self):
        self.crm = CRMManager()

    def get_smtp_settings(self):
        return {
            "smtp_host": self.crm.get_config("smtp_host", "smtp.gmail.com"),
            "smtp_port": int(self.crm.get_config("smtp_port", "587")),
            "sender_email": self.crm.get_config("sender_email", ""),
            "sender_password": self.crm.get_config("sender_password", ""),
            "sender_name": self.crm.get_config("sender_name", "Mohammad Hamza"),
            "agency_name": self.crm.get_config("agency_name", "Apex Digital Solutions")
        }

    def test_smtp_connection(self) -> dict:
        cfg = self.get_smtp_settings()
        if not cfg["sender_email"] or not cfg["sender_password"]:
            return {"success": False, "error": "Sender email or app password is not configured in Settings."}

        try:
            server = smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"], timeout=10)
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(cfg["sender_email"], cfg["sender_password"])
            server.quit()
            return {"success": True, "message": "SMTP connection & authentication successful! Ready to send."}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def send_email(self, recipient_email: str, subject: str, body: str) -> dict:
        cfg = self.get_smtp_settings()
        if not cfg["sender_email"] or not cfg["sender_password"]:
            return {"success": False, "error": "SMTP not configured. Please enter your Gmail/SMTP details in Settings."}

        if not recipient_email or "@" not in recipient_email:
            return {"success": False, "error": "Invalid recipient email address."}

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{cfg['sender_name']} <{cfg['sender_email']}>"
            msg["To"] = recipient_email
            msg["Reply-To"] = cfg["sender_email"]

            # Plain text part
            part_text = MIMEText(body, "plain", "utf-8")
            msg.attach(part_text)

            # Clean HTML part with nice linebreaks
            html_content = body.replace("\n", "<br>")
            part_html = MIMEText(f"<div style='font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6; color: #1e293b;'>{html_content}</div>", "html", "utf-8")
            msg.attach(part_html)

            server = smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"], timeout=15)
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(cfg["sender_email"], cfg["sender_password"])
            server.sendmail(cfg["sender_email"], [recipient_email], msg.as_string())
            server.quit()

            return {"success": True, "message": f"Email successfully sent to {recipient_email}!"}
        except Exception as e:
            return {"success": False, "error": str(e)}

if __name__ == "__main__":
    sender = EmailSender()
    print("Email sender module loaded successfully.")
