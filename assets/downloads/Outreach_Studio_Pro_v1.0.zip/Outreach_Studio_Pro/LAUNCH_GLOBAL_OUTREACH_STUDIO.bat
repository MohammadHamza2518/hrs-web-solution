@echo off
title Outreach Studio Pro — Enterprise Edition
cd /d "%~dp0"
color 0b

echo =======================================================================
echo   OUTREACH STUDIO PRO — ENTERPRISE EDITION
echo   High-Ticket Client Acquisition & Automated Global Lead CRM
echo =======================================================================
echo.

:: 1. Check if server is already running on port 5050
powershell -NoProfile -Command "$r = try { (Invoke-WebRequest -Uri 'http://127.0.0.1:5050' -UseBasicParsing -TimeoutSec 1).StatusCode } catch { 0 }; if ($r -eq 200) { exit 0 } else { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 (
    echo [*] Studio server is ALREADY RUNNING on port 5050!
    echo [*] Opening dashboard in your default browser...
    start http://localhost:5050
    ping 127.0.0.1 -n 3 >nul
    exit /b 0
)

:: 2. Dynamically Locate Python on any PC (User-independent)
set "PYTHON_EXE="

:: Try standard 'python' in PATH
where python >nul 2>nul
if %errorlevel% equ 0 (
    set "PYTHON_EXE=python"
    goto :python_found
)

:: Try Python Launcher 'py'
where py >nul 2>nul
if %errorlevel% equ 0 (
    set "PYTHON_EXE=py"
    goto :python_found
)

:: Try LocalAppData standard Python locations
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_EXE=%%D\python.exe"
        goto :python_found
    )
)

:: Try ProgramFiles Python
for /d %%D in ("%ProgramFiles%\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_EXE=%%D\python.exe"
        goto :python_found
    )
)

:python_found
if "%PYTHON_EXE%"=="" (
    color 0c
    echo =======================================================================
    echo [ERROR] Python 3 was not detected on your system!
    echo.
    echo To run Outreach Studio Pro on your PC:
    echo 1. Download Python from: https://www.python.org/downloads/
    echo 2. During installation, CHECK the box: "Add Python to PATH"
    echo =======================================================================
    echo.
    pause
    exit /b 1
)

echo [*] Starting Local Outreach Server on http://localhost:5050 ...
echo [*] Your browser will open automatically once the server is ready.
echo.
echo [!] IMPORTANT: Keep this command window open while using Outreach Studio!
echo =======================================================================
echo.

"%PYTHON_EXE%" server.py

if %errorlevel% neq 0 (
    echo.
    echo [!] Server exited with code %errorlevel%.
)

pause
