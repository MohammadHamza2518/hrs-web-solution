import time
import re
import sys
import urllib.parse
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
from crm_manager import CRMManager
from pitch_engine import GlobalPitchEngine

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

class InternationalScraper:
    def __init__(self, headless=True):
        self.headless = headless
        self.crm = CRMManager()
        self.is_running = False

    @staticmethod
    def detect_country(query: str, address: str = "") -> str:
        text = f"{query} {address}".lower()
        if any(w in text for w in ["switzerland", "schweiz", "suisse", "svizzera", "zurich", "zürich", "geneva", "genève", "basel", "lausanne", "bern", "lugano", "lucerne", "st. moritz", "zermatt"]):
            return "Switzerland"
        elif any(w in text for w in ["uae", "dubai", "abu dhabi", "sharjah", "emirates"]):
            return "UAE"
        elif any(w in text for w in ["canada", "toronto", "vancouver", "calgary", "montreal", "ottawa", "edmonton", "ontario", "quebec", "alberta", "bc"]):
            return "Canada"
        elif any(w in text for w in ["uk", "united kingdom", "london", "manchester", "birmingham", "leeds", "glasgow", "england", "scotland", "surrey"]):
            return "UK"
        elif any(w in text for w in ["australia", "sydney", "melbourne", "brisbane", "perth", "adelaide"]):
            return "Australia"
        elif any(w in text for w in ["germany", "france", "austria", "monaco", "luxembourg", "netherlands", "spain", "italy", "ireland", "dublin", "amsterdam", "berlin", "munich", "münchen", "frankfurt", "vienna", "wien", "paris"]):
            return "Europe"
        return "USA"

    @staticmethod
    def format_phone_for_country(raw_digits: str, country: str):
        """
        Formats numbers cleanly for display and for international WhatsApp/Tel.
        """
        if not raw_digits:
            return "", ""

        # Remove non-digits
        digits = re.sub(r"\D", "", raw_digits)

        if country == "Switzerland":
            # Swiss numbers: +41 XX XXX XX XX
            if digits.startswith("0") and len(digits) == 10:
                clean_wa = f"41{digits[1:]}"
                formatted = f"+41 {digits[1:3]} {digits[3:6]} {digits[6:]}"
            elif digits.startswith("41"):
                clean_wa = digits
                formatted = f"+{digits}"
            else:
                clean_wa = f"41{digits}"
                formatted = f"+41 {digits}"
        elif country == "UAE":
            # UAE numbers: +971 XX XXX XXXX
            if digits.startswith("0") and len(digits) == 10:
                clean_wa = f"971{digits[1:]}"
                formatted = f"+971 {digits[1:3]} {digits[3:]}"
            elif digits.startswith("971"):
                clean_wa = digits
                formatted = f"+{digits}"
            else:
                clean_wa = f"971{digits}"
                formatted = f"+971 {digits}"
        elif country in ["USA", "Canada"]:
            # Standard North American Numbering Plan (10 digits or 11 digits starting with 1)
            if len(digits) == 11 and digits.startswith("1"):
                clean_wa = digits
                formatted = f"+1 ({digits[1:4]}) {digits[4:7]}-{digits[7:]}"
            elif len(digits) == 10:
                clean_wa = f"1{digits}"
                formatted = f"+1 ({digits[0:3]}) {digits[3:6]}-{digits[6:]}"
            else:
                clean_wa = digits
                formatted = f"+{digits}"
        elif country == "UK":
            if digits.startswith("0") and len(digits) == 11:
                clean_wa = f"44{digits[1:]}"
                formatted = f"+44 {digits[1:5]} {digits[5:]}"
            elif digits.startswith("44"):
                clean_wa = digits
                formatted = f"+{digits}"
            else:
                clean_wa = digits
                formatted = f"+{digits}"
        elif country == "Australia":
            if digits.startswith("0") and len(digits) == 10:
                clean_wa = f"61{digits[1:]}"
                formatted = f"+61 {digits[1:]}"
            elif digits.startswith("61"):
                clean_wa = digits
                formatted = f"+{digits}"
            else:
                clean_wa = digits
                formatted = f"+{digits}"
        elif country == "Europe":
            if digits.startswith("0"):
                clean_wa = digits[1:]
                formatted = f"+{digits[1:]}"
            else:
                clean_wa = digits
                formatted = f"+{digits}"
        else:
            clean_wa = digits
            formatted = f"+{digits}"

        return clean_wa, formatted

    def scrape(self, query: str, max_leads: int = 15, no_website_only: bool = True, log_callback=None, service_type: str = "web_design"):
        """
        Scrapes Google Maps for international businesses, filters leads,
        generates personalized pitches based on service_type, and saves them to the CRM.
        """
        self.is_running = True
        country = self.detect_country(query)
        
        def log(msg):
            print(msg)
            if log_callback:
                try:
                    log_callback(msg)
                except Exception:
                    pass

        log(f"\n[Scraper] 🌐 Target Market: {country.upper()} | Query: '{query}' | Target Count: {max_leads}")
        encoded_query = urllib.parse.quote(query)
        maps_url = f"https://www.google.com/maps/search/{encoded_query}?hl=en"

        scraped_count = 0
        saved_leads = []

        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=self.headless,
                args=["--lang=en-US,en", "--disable-blink-features=AutomationControlled"]
            )
            context = browser.new_context(
                locale="en-US",
                viewport={"width": 1280, "height": 800},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            )
            page = context.new_page()

            try:
                log(f"[Scraper] 🚀 Loading Google Maps...")
                page.goto(maps_url, wait_until="domcontentloaded", timeout=45000)
                page.wait_for_timeout(3000)

                # Handle Google consent dialog if shown
                try:
                    accept_btn = page.query_selector("button:has-text('Accept all'), button:has-text('I agree'), button:has-text('Reject all')")
                    if accept_btn:
                        accept_btn.click()
                        page.wait_for_timeout(1000)
                except Exception:
                    pass

                # Scroll results list to discover place links
                log(f"[Scraper] 📜 Scrolling listings to find businesses...")
                for scroll_idx in range(6):
                    if not self.is_running:
                        break
                    try:
                        page.evaluate("""
                            const feed = document.querySelector('div[role="feed"]');
                            if (feed) { feed.scrollBy(0, 1800); }
                            else { window.scrollBy(0, 1200); }
                        """)
                        page.wait_for_timeout(2000)
                    except Exception:
                        break

                # Collect unique place URLs
                links = []
                for a in page.query_selector_all('a'):
                    href = a.get_attribute('href')
                    if href and '/maps/place/' in href and href not in links:
                        links.append(href)

                log(f"[Scraper] 🎯 Found {len(links)} places in {query}. Inspecting each business...")

                for idx, place_url in enumerate(links):
                    if not self.is_running or len(saved_leads) >= max_leads:
                        break

                    try:
                        page.goto(place_url, wait_until="domcontentloaded", timeout=25000)
                        page.wait_for_timeout(1500)

                        # 1. Business Name
                        name_el = page.query_selector("h1")
                        name = name_el.inner_text().strip() if name_el else ""
                        if not name:
                            continue

                        # 2. Check Website
                        web_el = page.query_selector("a[data-item-id='authority'], a[aria-label*='Website:'], a[aria-label*='website']")
                        website_url = web_el.get_attribute("href") if web_el else ""
                        
                        has_real_website = False
                        web_status = "No Website"

                        if website_url:
                            low_url = website_url.lower()
                            # Dead Google Site check
                            if "business.site" in low_url or "google.com/business" in low_url:
                                has_real_website = False
                                web_status = "Dead Google Site"
                            # Social directory / aggregators check
                            elif any(soc in low_url for soc in ["facebook.com", "instagram.com", "yelp.com", "yellowpages.", "bbb.org", "angi.com", "houzz.com", "linkedin.com"]):
                                has_real_website = False
                                web_status = "Social / Directory Only"
                            else:
                                has_real_website = True
                                web_status = "Official Website"

                        # Filter strictly if no_website_only requested
                        if no_website_only and has_real_website:
                            log(f"[{idx+1}/{len(links)}] ⏩ Skipped '{name}' (Already has official website)")
                            continue

                        # 3. Rating & Reviews
                        rating = 0.0
                        reviews_count = 0
                        rating_el = page.query_selector("span[aria-label*='stars'], div.fontDisplayLarge")
                        if rating_el:
                            txt = rating_el.get_attribute("aria-label") or rating_el.inner_text() or ""
                            m = re.search(r"(\d+(\.\d+)?)", txt)
                            if m:
                                rating = float(m.group(1))

                        reviews_el = page.query_selector("span[aria-label*='reviews'], button:has-text('reviews')")
                        if reviews_el:
                            rev_text = reviews_el.inner_text() or reviews_el.get_attribute("aria-label") or ""
                            rev_m = re.search(r"([\d,]+)", rev_text)
                            if rev_m:
                                reviews_count = int(rev_m.group(1).replace(",", ""))

                        # 4. Category
                        category = ""
                        cat_el = page.query_selector("button[jsaction*='category']")
                        if cat_el:
                            category = cat_el.inner_text().strip()
                        if not category and " in " in query:
                            category = query.split(" in ")[0].strip()

                        # 5. Address
                        address = ""
                        addr_el = page.query_selector("button[data-item-id*='address'], button[aria-label*='Address:']")
                        if addr_el:
                            address = addr_el.inner_text().strip()

                        # 6. Phone
                        raw_phone = ""
                        phone_el = page.query_selector("button[data-item-id*='phone'], button[aria-label*='Phone:']")
                        if phone_el:
                            raw_phone = phone_el.get_attribute("aria-label") or phone_el.inner_text() or ""

                        if not raw_phone:
                            # Fallback search in page body
                            body_text = page.inner_text("body")
                            # North America format: (123) 456-7890 or 123-456-7890 or +1-123-456-7890
                            us_matches = re.findall(r"(?:\+?1[\s-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}", body_text)
                            if us_matches:
                                raw_phone = us_matches[0]

                        clean_wa, display_phone = self.format_phone_for_country(raw_phone, country)

                        # 7. Email detection
                        email = ""
                        # Try to detect email on Maps page or text
                        page_html = page.content()
                        mail_matches = re.findall(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', page_html)
                        valid_emails = [e for e in mail_matches if not any(x in e.lower() for x in ["google", "schema.org", "sentry", "w3.org", "domain.com", "example.com"])]
                        if valid_emails:
                            email = valid_emails[0]

                        # Extract City from query or address
                        city = ""
                        if " in " in query:
                            city = query.split(" in ")[-1].strip()
                        elif address:
                            parts = address.split(",")
                            if len(parts) >= 2:
                                city = parts[-2].strip()

                        lead_dict = {
                            "business_name": name,
                            "phone": clean_wa,
                            "display_phone": display_phone or raw_phone,
                            "raw_phone": raw_phone,
                            "email": email,
                            "country": country,
                            "city": city,
                            "category": category,
                            "rating": rating,
                            "reviews_count": reviews_count,
                            "address": address,
                            "google_maps_url": place_url,
                            "has_website": 1 if has_real_website else 0,
                            "website_url": website_url,
                            "web_status": web_status,
                            "status": "NEW"
                        }

                        # Generate AI psychological pitches for both Email & WhatsApp
                        sender_name = self.crm.get_config("sender_name", "Mohammad Hamza")
                        agency_name = self.crm.get_config("agency_name", "HRS Web Solution")
                        sender_email = self.crm.get_config("sender_email", "hrswebsolution@gmail.com")
                        sender_phone = self.crm.get_config("sender_phone", "+91 8808129388")
                        gemini_key = self.crm.get_config("gemini_api_key", "").strip()
                        ai_model = self.crm.get_config("ai_model", "gemini-1.5-flash").strip()

                        pitches = GlobalPitchEngine.generate_pitches(
                            lead_dict,
                            sender_name=sender_name,
                            agency_name=agency_name,
                            sender_email=sender_email,
                            sender_phone=sender_phone,
                            api_key=gemini_key,
                            model=ai_model,
                            service_type=service_type
                        )
                        lead_dict["service_type"] = service_type
                        lead_dict["pitch_message"] = pitches["whatsapp_message"]
                        lead_dict["email_pitch"] = f"Subject: {pitches['email_subject']}\n\n{pitches['email_body']}"

                        # Save to database
                        saved = self.crm.add_lead(lead_dict)
                        if saved:
                            saved_leads.append(lead_dict)
                            status_tag = f"🔥 [{web_status.upper()}]"
                            log(f"[{len(saved_leads)}/{max_leads}] {status_tag} {name} | {country} | Phone: {display_phone or 'N/A'} | Rating: {rating}★")
                        else:
                            log(f"[{idx+1}/{len(links)}] ℹ️ Already in CRM: {name}")

                    except Exception as err:
                        log(f"[Scraper] ⚠️ Error on listing {idx+1}: {err}")
                        continue

            except Exception as e:
                log(f"[Scraper] ❌ Scraper error: {e}")
            finally:
                browser.close()
                self.is_running = False

        log(f"\n[Scraper] ✅ Finished! Discovered and added {len(saved_leads)} hot leads without official website.")
        return saved_leads

if __name__ == "__main__":
    scraper = InternationalScraper(headless=True)
    res = scraper.scrape(query="Plumber in Toronto", max_leads=2, no_website_only=False)
    print(f"Total scraped: {len(res)}")
