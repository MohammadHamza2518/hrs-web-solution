import time
import re
import sys
import urllib.parse
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
from crm_manager import CRMManager
from config import DATA_DIR

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

class GoogleMapsScraper:
    def __init__(self, headless=True):
        self.headless = headless
        self.crm = CRMManager()

    def scrape_leads(self, query: str, max_leads: int = 15, target_no_website_only: bool = True):
        """
        Scrapes Google Maps for a query (e.g. 'Dental Clinic in Gurgaon').
        Identifies businesses, checks website presence, extracts phone numbers,
        and saves hot leads into CRM.
        """
        print(f"\n[Scraper] 🔍 Starting search for: '{query}'...")
        encoded_query = urllib.parse.quote(query)
        maps_url = f"https://www.google.com/maps/search/{encoded_query}?hl=en"

        scraped_leads = []
        no_website_leads = []

        with sync_playwright() as p:
            # Launch browser with standard user-agent
            browser = p.chromium.launch(
                headless=self.headless,
                args=["--lang=en-US,en", "--disable-blink-features=AutomationControlled"]
            )
            context = browser.new_context(
                locale="en-US",
                viewport={"width": 1280, "height": 800},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            page = context.new_page()

            try:
                page.goto(maps_url, wait_until="domcontentloaded", timeout=45000)
                time.sleep(3)

                # Dismiss consent dialog if any
                try:
                    accept_btn = page.query_selector("button:has-text('Accept all'), button:has-text('I agree')")
                    if accept_btn:
                        accept_btn.click()
                        time.sleep(1)
                except Exception:
                    pass

                # Locate feed list
                feed_selector = 'div[role="feed"]'
                try:
                    page.wait_for_selector(feed_selector, timeout=10000)
                except PlaywrightTimeoutError:
                    print("[Scraper] ⚠️ Direct feed not found, waiting for place listings...")

                # Scroll down to load more results
                print("[Scraper] 📜 Scrolling listings feed...")
                for _ in range(4):
                    try:
                        page.evaluate("""
                            const feed = document.querySelector('div[role="feed"]');
                            if (feed) { feed.scrollBy(0, 1500); }
                            else { window.scrollBy(0, 1000); }
                        """)
                        time.sleep(2)
                    except Exception:
                        break

                # Collect all place links
                listing_elements = page.query_selector_all('a[href*="/maps/place/"]')
                place_urls = []
                for el in listing_elements:
                    href = el.get_attribute("href")
                    if href and href not in place_urls:
                        place_urls.append(href)

                print(f"[Scraper] 🎯 Found {len(place_urls)} places on Google Maps. Inspecting details...")

                for idx, url in enumerate(place_urls[:max_leads * 2]):
                    if len(no_website_leads) >= max_leads:
                        break

                    try:
                        page.goto(url, wait_until="domcontentloaded", timeout=25000)
                        time.sleep(1.5)

                        # 1. Business Name
                        name_el = page.query_selector("h1")
                        name = name_el.inner_text().strip() if name_el else ""
                        if not name:
                            continue

                        # 2. Rating & Reviews
                        rating = 0.0
                        reviews_count = 0
                        rating_el = page.query_selector("span[aria-label*='stars'], div.fontDisplayLarge")
                        if rating_el:
                            aria_label = rating_el.get_attribute("aria-label") or rating_el.inner_text()
                            match = re.search(r"(\d+(\.\d+)?)", aria_label)
                            if match:
                                rating = float(match.group(1))

                        reviews_el = page.query_selector("span[aria-label*='reviews'], button:has-text('reviews')")
                        if reviews_el:
                            rev_text = reviews_el.inner_text() or reviews_el.get_attribute("aria-label") or ""
                            rev_match = re.search(r"([\d,]+)", rev_text)
                            if rev_match:
                                reviews_count = int(rev_match.group(1).replace(",", ""))

                        # 3. Category
                        category = ""
                        cat_el = page.query_selector("button[jsaction*='category']")
                        if cat_el:
                            category = cat_el.inner_text().strip()

                        # 4. Website Check (THE CRUCIAL FILTER)
                        has_website = False
                        website_url = ""
                        web_el = page.query_selector("a[data-item-id='authority'], a[aria-label*='Website:']")
                        if web_el:
                            href = web_el.get_attribute("href") or ""
                            # Ignore social/aggregator profiles as 'official website'
                            aggregators = ["facebook.com", "instagram.com", "justdial.com", "indiamart.com", "sulekha.com"]
                            if any(agg in href.lower() for agg in aggregators):
                                has_website = False
                                website_url = href
                            elif href.strip():
                                has_website = True
                                website_url = href

                        # 5. Phone Number
                        phone = ""
                        phone_el = page.query_selector("button[data-item-id*='phone'], button[aria-label*='Phone:']")
                        if phone_el:
                            phone_text = phone_el.get_attribute("aria-label") or phone_el.inner_text() or ""
                            # Extract phone digits and formatting
                            phone_clean = re.sub(r"[^\d+]", "", phone_text)
                            if len(phone_clean) >= 10:
                                phone = phone_clean

                        # Fallback phone search on page text if button missing
                        if not phone:
                            body_text = page.inner_text("body")
                            phone_matches = re.findall(r"(?:\+91[\s-]?)?[6789]\d{9}", body_text)
                            if phone_matches:
                                phone = phone_matches[0]

                        # 6. Address
                        address = ""
                        addr_el = page.query_selector("button[data-item-id*='address'], button[aria-label*='Address:']")
                        if addr_el:
                            address = addr_el.inner_text().strip()

                        lead_info = {
                            "business_name": name,
                            "phone": phone,
                            "category": category or query.split(" in ")[0],
                            "city": query.split(" in ")[-1] if " in " in query else "",
                            "rating": rating,
                            "reviews_count": reviews_count,
                            "address": address,
                            "google_maps_url": url,
                            "has_website": has_website,
                            "website_url": website_url,
                            "status": "NEW"
                        }

                        # Save to CRM if has phone
                        saved = self.crm.add_lead(lead_info)

                        scraped_leads.append(lead_info)
                        if not has_website and phone:
                            no_website_leads.append(lead_info)
                            tag = "🔥 [HOT LEAD - NO WEBSITE]"
                        elif has_website:
                            tag = "ℹ️ [Has Website]"
                        else:
                            tag = "⚠️ [No Phone]"

                        print(f"[{idx+1}] {tag} {name} | Phone: {phone or 'N/A'} | Rating: {rating}★")

                    except Exception as item_err:
                        # Skip failed single listing and proceed
                        continue

            except Exception as e:
                print(f"[Scraper] ❌ Error during scraping: {e}")
            finally:
                browser.close()

        print(f"\n[Scraper] ✅ Finished! Total Discovered: {len(scraped_leads)} | High-Value Leads without Website: {len(no_website_leads)}")
        return no_website_leads if target_no_website_only else scraped_leads

if __name__ == "__main__":
    scraper = GoogleMapsScraper(headless=True)
    results = scraper.scrape_leads(query="Dental clinic in Gurgaon Sector 29", max_leads=5)
    print(f"\nFound {len(results)} target leads.")
