import json
import sqlite3
import datetime
import os
import re
import xlsxwriter
from config import DB_PATH, EXCEL_REPORT_PATH, DATA_DIR

class CRMManager:
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self._init_db()

    def _get_conn(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS leads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_name TEXT NOT NULL,
                    phone TEXT,
                    raw_phone TEXT,
                    email TEXT,
                    owner_name TEXT DEFAULT 'Owner / Founder',
                    country TEXT DEFAULT 'USA',
                    category TEXT,
                    city TEXT,
                    rating REAL DEFAULT 0.0,
                    reviews_count INTEGER DEFAULT 0,
                    address TEXT,
                    google_maps_url TEXT,
                    has_website INTEGER DEFAULT 0,
                    website_url TEXT,
                    pitch_message TEXT,
                    email_pitch TEXT,
                    notes TEXT,
                    status TEXT DEFAULT 'NEW',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    sent_at TIMESTAMP,
                    email_sent_at TIMESTAMP,
                    source TEXT DEFAULT 'Google Maps',
                    source_url TEXT,
                    audit_proof TEXT
                )
            """)
            cursor.execute("PRAGMA table_info(leads)")
            existing_cols = [c[1] for c in cursor.fetchall()]
            if 'source' not in existing_cols:
                cursor.execute("ALTER TABLE leads ADD COLUMN source TEXT DEFAULT 'Google Maps'")
            if 'source_url' not in existing_cols:
                cursor.execute("ALTER TABLE leads ADD COLUMN source_url TEXT")
            if 'audit_proof' not in existing_cols:
                cursor.execute("ALTER TABLE leads ADD COLUMN audit_proof TEXT")
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS outreach_config (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            conn.commit()
        self.auto_restore_if_empty()

    
    def get_backup_path(self):
        return os.path.join(DATA_DIR, "crm_persistent_store.json")

    def save_backup(self):
        """Atomically saves complete leads & outreach config into persistent JSON snapshot."""
        try:
            with self._get_conn() as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM leads ORDER BY id ASC")
                leads = [dict(r) for r in cursor.fetchall()]
                cursor.execute("SELECT key, value FROM outreach_config")
                config = {r["key"]: r["value"] for r in cursor.fetchall()}

            payload = {
                "version": "1.0",
                "last_saved_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "total_leads": len(leads),
                "config": config,
                "leads": leads
            }

            backup_file = self.get_backup_path()
            tmp_file = backup_file + ".tmp"
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)

            if os.path.exists(backup_file):
                os.replace(tmp_file, backup_file)
            else:
                os.rename(tmp_file, backup_file)
        except Exception as e:
            print(f"Warning: Persistent snapshot failed: {e}")

    def auto_restore_if_empty(self):
        """Self-healing: If database is freshly initialized or empty, auto-restores from persistent JSON snapshot."""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM leads")
                count = cursor.fetchone()[0]
                if count > 0:
                    # Database has data, ensure snapshot is fresh
                    self.save_backup()
                    return

            backup_file = self.get_backup_path()
            if not os.path.exists(backup_file):
                return

            with open(backup_file, "r", encoding="utf-8") as f:
                payload = json.load(f)

            leads = payload.get("leads", [])
            config = payload.get("config", {})

            with self._get_conn() as conn:
                cursor = conn.cursor()
                for k, v in config.items():
                    cursor.execute("INSERT OR REPLACE INTO outreach_config (key, value) VALUES (?, ?)", (k, v))

                for l in leads:
                    cursor.execute("""
                        INSERT OR REPLACE INTO leads (
                            id, business_name, phone, raw_phone, email, owner_name, country, category,
                            city, rating, reviews_count, address, google_maps_url, has_website,
                            website_url, pitch_message, email_pitch, notes, status, created_at,
                            sent_at, email_sent_at, source, source_url, audit_proof
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        l.get("id"), l.get("business_name"), l.get("phone"), l.get("raw_phone"),
                        l.get("email"), l.get("owner_name", "Owner / Founder"), l.get("country", "USA"),
                        l.get("category"), l.get("city"), l.get("rating", 0.0), l.get("reviews_count", 0),
                        l.get("address"), l.get("google_maps_url"), l.get("has_website", 0),
                        l.get("website_url"), l.get("pitch_message"), l.get("email_pitch"),
                        l.get("notes"), l.get("status", "NEW"), l.get("created_at"),
                        l.get("sent_at"), l.get("email_sent_at"),
                        l.get("source", "Google Maps"), l.get("source_url", ""), l.get("audit_proof", "")
                    ))
                conn.commit()
            print(f"[CRM Self-Healing] Restored: {len(leads)} leads and {len(config)} configurations from persistent store!")
        except Exception as e:
            print(f"Warning: Auto-restore from backup store failed: {e}")

    def add_lead(self, lead_data: dict) -> bool:
        """Inserts a new lead into the database. Returns True if inserted, False if duplicate."""
        biz_name = lead_data.get("business_name", "").strip()
        if not biz_name:
            return False

        phone = lead_data.get("phone", "").strip()
        email = lead_data.get("email", "").strip()
        city = lead_data.get("city", "").strip()

        with self._get_conn() as conn:
            cursor = conn.cursor()
            # Check duplicate by phone (if available) or by business_name + city
            if phone:
                cursor.execute("SELECT id FROM leads WHERE phone = ? AND phone != ''", (phone,))
                if cursor.fetchone():
                    return False
            
            cursor.execute("SELECT id FROM leads WHERE LOWER(business_name) = ? AND LOWER(city) = ?", (biz_name.lower(), city.lower()))
            if cursor.fetchone():
                return False

            try:
                cursor.execute("""
                    INSERT INTO leads (
                        business_name, phone, raw_phone, email, owner_name, country, category, city,
                        rating, reviews_count, address, google_maps_url,
                        has_website, website_url, pitch_message, email_pitch, status,
                        source, source_url, audit_proof
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    biz_name,
                    phone,
                    lead_data.get("raw_phone", "").strip() or lead_data.get("display_phone", ""),
                    email,
                    lead_data.get("owner_name", "Owner / Founder"),
                    lead_data.get("country", "USA"),
                    lead_data.get("category", "").strip(),
                    city,
                    lead_data.get("rating", 0.0),
                    lead_data.get("reviews_count", 0),
                    lead_data.get("address", "").strip(),
                    lead_data.get("google_maps_url", "").strip(),
                    1 if lead_data.get("has_website") else 0,
                    lead_data.get("website_url", "").strip(),
                    lead_data.get("pitch_message", "").strip(),
                    lead_data.get("email_pitch", "").strip(),
                    lead_data.get("status", "NEW"),
                    lead_data.get("source", "Google Maps").strip(),
                    lead_data.get("source_url", "").strip(),
                    lead_data.get("audit_proof", "").strip()
                ))
                conn.commit()
                return True
            except Exception as e:
                print(f"[CRM] Error adding lead: {e}")
                return False

    def get_leads(self, country=None, source=None, status=None, category=None, search=None, no_website_only=False, sent_filter=None):
        """Fetches leads matching various filters including sent/unsent status."""
        with self._get_conn() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            query = "SELECT * FROM leads WHERE 1=1"
            params = []

            if no_website_only:
                query += " AND has_website = 0"
            if country and country.lower() != "all":
                query += " AND LOWER(country) = ?"
                params.append(country.lower())
            if source and source.lower() != "all":
                s_lower = source.lower()
                if "meta" in s_lower:
                    query += " AND LOWER(source) LIKE '%meta%'"
                elif "instagram" in s_lower or "fb" in s_lower or "social" in s_lower:
                    query += " AND (LOWER(source) LIKE '%instagram%' OR LOWER(source) LIKE '%fb%' OR LOWER(source) LIKE '%social%')"
                elif "google ads" in s_lower:
                    query += " AND LOWER(source) LIKE '%google ads%'"
                elif "maps" in s_lower:
                    query += " AND LOWER(source) LIKE '%maps%'"
                else:
                    query += " AND LOWER(source) LIKE ?"
                    params.append(f"%{s_lower}%")
            if status and status.lower() != "all":
                query += " AND status = ?"
                params.append(status)
            if category and category.lower() != "all":
                query += " AND LOWER(category) LIKE ?"
                params.append(f"%{category.lower()}%")
            if sent_filter and sent_filter.lower() != "all":
                sf = sent_filter.lower()
                if sf == "unsent":
                    query += " AND (sent_at IS NULL AND email_sent_at IS NULL AND (status = 'NEW' OR status IS NULL))"
                elif sf in ["both_sent", "completed"]:
                    query += " AND ((sent_at IS NOT NULL AND email_sent_at IS NOT NULL) OR status = 'PITCHED_BOTH')"
                elif sf in ["pending", "pending_outreach", "incomplete"]:
                    query += " AND NOT ((sent_at IS NOT NULL AND email_sent_at IS NOT NULL) OR status = 'PITCHED_BOTH')"
                elif sf == "sent":
                    query += " AND (sent_at IS NOT NULL OR email_sent_at IS NOT NULL OR status IN ('PITCHED_WHATSAPP', 'PITCHED_EMAIL', 'PITCHED_BOTH', 'INTERESTED', 'MEETING_SCHEDULED', 'CLOSED'))"
                elif sf == "wa_sent":
                    query += " AND (sent_at IS NOT NULL OR status IN ('PITCHED_WHATSAPP', 'PITCHED_BOTH'))"
                elif sf == "email_sent":
                    query += " AND (email_sent_at IS NOT NULL OR status IN ('PITCHED_EMAIL', 'PITCHED_BOTH'))"
            if search:
                query += " AND (LOWER(business_name) LIKE ? OR LOWER(city) LIKE ? OR LOWER(address) LIKE ? OR phone LIKE ? OR email LIKE ? OR LOWER(audit_proof) LIKE ?)"
                kw = f"%{search.lower()}%"
                params.extend([kw, kw, kw, kw, kw, kw])

            query += " ORDER BY id DESC"
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_lead_by_id(self, lead_id: int):
        with self._get_conn() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM leads WHERE id = ?", (lead_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def update_lead_pitches(self, lead_id: int, wa_pitch: str = None, email_pitch: str = None):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            if wa_pitch and email_pitch:
                cursor.execute("UPDATE leads SET pitch_message = ?, email_pitch = ? WHERE id = ?", (wa_pitch, email_pitch, lead_id))
            elif wa_pitch:
                cursor.execute("UPDATE leads SET pitch_message = ? WHERE id = ?", (wa_pitch, lead_id))
            elif email_pitch:
                cursor.execute("UPDATE leads SET email_pitch = ? WHERE id = ?", (email_pitch, lead_id))
            conn.commit()
        self.save_backup()

    def mark_whatsapp_sent(self, lead_id: int):
        """Marks a lead as messaged on WhatsApp with timestamp and updates status."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("SELECT email_sent_at, status FROM leads WHERE id = ?", (lead_id,))
            row = cursor.fetchone()
            email_sent = row and row[0]
            curr_status = row[1] if row else ""
            
            if curr_status in ["INTERESTED", "MEETING_SCHEDULED", "MEETING_SET", "CLOSED"]:
                new_status = curr_status
            elif email_sent:
                new_status = "PITCHED_BOTH"
            else:
                new_status = "PITCHED_WHATSAPP"
                
            cursor.execute("UPDATE leads SET status = ?, sent_at = ? WHERE id = ?", (new_status, now_str, lead_id))
            conn.commit()
            self.save_backup()
            return {"id": lead_id, "status": new_status, "sent_at": now_str}

    def mark_email_sent(self, lead_id: int):
        """Marks a lead as emailed with timestamp and updates status."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("SELECT sent_at, status FROM leads WHERE id = ?", (lead_id,))
            row = cursor.fetchone()
            wa_sent = row and row[0]
            curr_status = row[1] if row else ""
            
            if curr_status in ["INTERESTED", "MEETING_SCHEDULED", "MEETING_SET", "CLOSED"]:
                new_status = curr_status
            elif wa_sent:
                new_status = "PITCHED_BOTH"
            else:
                new_status = "PITCHED_EMAIL"
                
            cursor.execute("UPDATE leads SET status = ?, email_sent_at = ? WHERE id = ?", (new_status, now_str, lead_id))
            conn.commit()
            self.save_backup()
            return {"id": lead_id, "status": new_status, "email_sent_at": now_str}

    def update_lead_status(self, lead_id: int, status: str):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if "WHATSAPP" in status or status == "MESSAGE_SENT":
                cursor.execute("UPDATE leads SET status = ?, sent_at = ? WHERE id = ?", (status, now_str, lead_id))
            elif "EMAIL" in status:
                cursor.execute("UPDATE leads SET status = ?, email_sent_at = ? WHERE id = ?", (status, now_str, lead_id))
            elif status == "PITCHED_BOTH":
                cursor.execute("UPDATE leads SET status = ?, sent_at = COALESCE(sent_at, ?), email_sent_at = COALESCE(email_sent_at, ?) WHERE id = ?", (status, now_str, now_str, lead_id))
            elif status == "NEW":
                # Reset status back to NEW and clear timestamps so it returns to fresh queue
                cursor.execute("UPDATE leads SET status = ?, sent_at = NULL, email_sent_at = NULL WHERE id = ?", (status, lead_id))
            else:
                cursor.execute("UPDATE leads SET status = ? WHERE id = ?", (status, lead_id))
            conn.commit()
        self.save_backup()

    def update_lead_contact(self, lead_id: int, phone: str = None, email: str = None, notes: str = None):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            updates = []
            params = []
            if phone is not None:
                updates.append("phone = ?")
                params.append(phone)
            if email is not None:
                updates.append("email = ?")
                params.append(email)
            if notes is not None:
                updates.append("notes = ?")
                params.append(notes)
            if updates:
                params.append(lead_id)
                cursor.execute(f"UPDATE leads SET {', '.join(updates)} WHERE id = ?", params)
                conn.commit()
                self.save_backup()

    def delete_lead(self, lead_id: int):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
            conn.commit()

    def get_stats(self):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM leads")
            total = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE has_website = 0")
            no_website = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE status IN ('PITCHED_EMAIL', 'EMAIL_SENT', 'PITCHED_BOTH') OR email_sent_at IS NOT NULL")
            email_sent = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE status IN ('PITCHED_WHATSAPP', 'MESSAGE_SENT', 'PITCHED_BOTH') OR sent_at IS NOT NULL")
            wa_sent = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE (sent_at IS NOT NULL AND email_sent_at IS NOT NULL) OR status = 'PITCHED_BOTH'")
            both_sent = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE sent_at IS NULL AND email_sent_at IS NULL AND (status IN ('NEW', 'pending') OR status IS NULL)")
            fresh_uncontacted = cursor.fetchone()[0]

            pending_outreach = max(0, total - both_sent)

            cursor.execute("SELECT COUNT(*) FROM leads WHERE status IN ('INTERESTED', 'MEETING_SET', 'MEETING_SCHEDULED')")
            meetings = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE status = 'CLOSED'")
            closed = cursor.fetchone()[0]

            # Today Anti-Ban tracking (robust against timezone differences)
            today_date = datetime.date.today().strftime("%Y-%m-%d")
            cursor.execute("SELECT COUNT(*) FROM leads WHERE sent_at IS NOT NULL AND (DATE(sent_at) = DATE('now', 'localtime') OR sent_at LIKE ?)", (f"{today_date}%",))
            today_wa = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE email_sent_at IS NOT NULL AND (DATE(email_sent_at) = DATE('now', 'localtime') OR email_sent_at LIKE ?)", (f"{today_date}%",))
            today_email = cursor.fetchone()[0]

            try:
                wa_limit = int(self.get_config("daily_wa_limit", "50"))
            except Exception:
                wa_limit = 50
            try:
                email_limit = int(self.get_config("daily_email_limit", "100"))
            except Exception:
                email_limit = 100

            # Country counts
            cursor.execute("SELECT country, COUNT(*) FROM leads GROUP BY country")
            by_country = {row[0] or "Unknown": row[1] for row in cursor.fetchall()}

            # Source counts mapped directly to UI filter tabs
            cursor.execute("SELECT COUNT(*) FROM leads WHERE LOWER(source) LIKE '%maps%'")
            maps_cnt = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE LOWER(source) LIKE '%meta%'")
            meta_cnt = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE LOWER(source) LIKE '%instagram%' OR LOWER(source) LIKE '%fb%' OR LOWER(source) LIKE '%social%'")
            social_cnt = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE LOWER(source) LIKE '%google ads%'")
            gads_cnt = cursor.fetchone()[0]

            by_source = {
                "Google Maps": maps_cnt,
                "Meta Ads Library": meta_cnt,
                "Instagram / FB": social_cnt,
                "Google Ads": gads_cnt
            }

            return {
                "total_leads": total,
                "no_website": no_website,
                "email_sent": email_sent,
                "whatsapp_sent": wa_sent,
                "both_sent": both_sent,
                "fresh_uncontacted": fresh_uncontacted,
                "pending_outreach": pending_outreach,
                "meetings_booked": meetings,
                "closed_deals": closed,
                "today_whatsapp_count": today_wa,
                "today_email_count": today_email,
                "daily_wa_limit": wa_limit,
                "daily_email_limit": email_limit,
                "wa_remaining_today": max(0, wa_limit - today_wa),
                "email_remaining_today": max(0, email_limit - today_email),
                "wa_limit_reached": today_wa >= wa_limit,
                "email_limit_reached": today_email >= email_limit,
                "by_country": by_country,
                "by_source": by_source
            }

    def get_config(self, key: str, default: str = "") -> str:
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM outreach_config WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row[0] if row else default

    def set_config(self, key: str, value: str):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO outreach_config (key, value) VALUES (?, ?)", (key, value))
            conn.commit()
        self.save_backup()

    def get_all_config(self) -> dict:
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM outreach_config")
            return {row[0]: row[1] for row in cursor.fetchall()}

    def export_to_excel(self, output_path=EXCEL_REPORT_PATH) -> str:
        leads = self.get_leads()
        workbook = xlsxwriter.Workbook(output_path)
        worksheet = workbook.add_worksheet("Global Leads")

        header_fmt = workbook.add_format({
            "bold": True, "bg_color": "#0F172A", "font_color": "#38BDF8",
            "border": 1, "align": "center", "valign": "vcenter", "font_size": 11
        })
        cell_fmt = workbook.add_format({"border": 1, "valign": "vcenter", "font_size": 10})
        tag_noweb_fmt = workbook.add_format({"bg_color": "#FEE2E2", "font_color": "#991B1B", "bold": True, "border": 1, "align": "center"})
        tag_sent_fmt = workbook.add_format({"bg_color": "#DCFCE7", "font_color": "#166534", "bold": True, "border": 1, "align": "center"})

        headers = [
            "ID", "Business Name", "Country", "City", "Category", "Lead Source", "Audit / Proof Note", "Rating", "Reviews",
            "Phone (WhatsApp)", "Email", "Website Status", "Outreach Status", "WhatsApp Sent At", "Email Sent At", "Source Proof URL"
        ]

        worksheet.set_row(0, 26)
        for col_idx, h in enumerate(headers):
            worksheet.write(0, col_idx, h, header_fmt)

        col_widths = [6, 32, 12, 18, 22, 20, 45, 10, 10, 20, 26, 18, 20, 20, 20, 40]
        for idx, w in enumerate(col_widths):
            worksheet.set_column(idx, idx, w)

        for row_idx, lead in enumerate(leads, start=1):
            worksheet.set_row(row_idx, 20)
            worksheet.write(row_idx, 0, lead["id"], cell_fmt)
            worksheet.write(row_idx, 1, lead["business_name"], cell_fmt)
            worksheet.write(row_idx, 2, lead["country"] or "USA", cell_fmt)
            worksheet.write(row_idx, 3, lead["city"] or "", cell_fmt)
            worksheet.write(row_idx, 4, lead["category"] or "", cell_fmt)
            worksheet.write(row_idx, 5, lead["source"] or "Google Maps", cell_fmt)
            worksheet.write(row_idx, 6, lead["audit_proof"] or "", cell_fmt)
            worksheet.write(row_idx, 7, lead["rating"] or 0, cell_fmt)
            worksheet.write(row_idx, 8, lead["reviews_count"] or 0, cell_fmt)
            worksheet.write(row_idx, 9, lead["phone"] or "", cell_fmt)
            worksheet.write(row_idx, 10, lead["email"] or "", cell_fmt)

            w_stat = "No Website" if not lead["has_website"] else "Has Website"
            w_fmt = tag_noweb_fmt if not lead["has_website"] else cell_fmt
            worksheet.write(row_idx, 11, w_stat, w_fmt)

            stat = lead["status"]
            s_fmt = tag_sent_fmt if "SENT" in stat or "PITCHED" in stat or stat in ["INTERESTED", "MEETING_SET", "CLOSED"] else cell_fmt
            worksheet.write(row_idx, 12, stat, s_fmt)
            worksheet.write(row_idx, 13, lead["sent_at"] or "", cell_fmt)
            worksheet.write(row_idx, 14, lead["email_sent_at"] or "", cell_fmt)
            worksheet.write(row_idx, 15, lead["source_url"] or lead["google_maps_url"] or "", cell_fmt)

        workbook.close()
        return output_path
