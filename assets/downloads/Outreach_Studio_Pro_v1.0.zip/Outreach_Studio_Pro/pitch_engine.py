import random
import re
import sys
import json
import urllib.request
import urllib.error

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

class GlobalPitchEngine:
    """
    Ultra-natural, human cold outreach engine.
    Crafted so business name, city, and lead source blend seamlessly
    into the conversation rather than feeling like a formal application or bot template.

    Guarantees:
    - Never sounds like a formal application or generic sales letter.
    - Zero mentions of 'free', 'demo', 'website demo', or '1 page' / '2 page'.
    - Zero spam symbols: no stars, no hashtags, no emojis.
    - Casual, genuine human-to-human tone.
    """

    NICHE_TERMS = [
        ("tax", "tax and accounting practices"),
        ("accounting", "accounting firms"),
        ("bookkeeping", "bookkeeping and advisory firms"),
        ("scaffolding", "scaffolding specialists"),
        ("glazing", "glazing and window specialists"),
        ("heating", "heating engineering firms"),
        ("mechanical", "mechanical engineering services"),
        ("carpentry", "custom carpentry and building firms"),
        ("remodel", "remodeling contractors"),
        ("renovation", "renovation and construction specialists"),
        ("builder", "builders and construction firms"),
        ("building", "building and construction firms"),
        ("construction", "construction companies"),
        ("contract", "general contractors"),
        ("logistics", "logistics companies"),
        ("freight", "freight and transport companies"),
        ("transport", "transport companies"),
        ("dental", "dental practices"),
        ("aesthetic", "aesthetic clinics"),
        ("salon", "salons and spas"),
        ("roofing", "roofing contractors"),
        ("plumbing", "plumbing companies"),
        ("hvac", "HVAC specialists"),
        ("auto", "auto detailing specialists"),
        ("fitness", "fitness studios"),
        ("restaurant", "restaurants"),
        ("law", "law firms")
    ]

    @classmethod
    def get_term_for_category(cls, category: str) -> str:
        cat_lower = (category or "").lower()
        for key, val in cls.NICHE_TERMS:
            if key in cat_lower:
                return val
        return "local businesses"

    @classmethod
    def _format_rating_text(cls, rating, reviews):
        try:
            r_num = float(rating)
        except (ValueError, TypeError):
            r_num = 0.0

        try:
            rev_num = int(reviews)
        except (ValueError, TypeError):
            rev_num = 0

        if r_num >= 4.0:
            if rev_num > 5:
                return f"{r_num} rating and solid reviews"
            return f"{r_num} rating"
        return "great reviews"

    @classmethod
    def generate_email_pitch(cls, lead: dict, sender_name: str = "Mohammad Hamza", agency_name: str = "HRS Web Solution", sender_email: str = "hrswebsolution@gmail.com", sender_phone: str = "+91 8808129388", service_type: str = "web_design", portfolio_url: str = "") -> dict:
        biz_name = lead.get("business_name", "your business").strip()
        city = lead.get("city", "").strip() or "your area"
        rating = lead.get("rating", 4.9)
        reviews = lead.get("reviews_count", 0)
        category = lead.get("category", "Local Business").strip()
        source = lead.get("source", "Google Maps").strip()
        term = cls.get_term_for_category(category)
        rating_text = cls._format_rating_text(rating, reviews)

        if service_type == "video_editing":
            subject = f"quick video concept demo for {biz_name}"
            body = (
                f"Hi there,\n\n"
                f"Came across {biz_name} in {city}—really solid work and presentation!\n\n"
                f"I noticed you guys share great content but aren't fully leveraging short-form video & viral reels to bring in new clients. A lot of local businesses are tripling their reach with high-retention editing, dynamic captions, and hook-based reels.\n\n"
                f"I put together a quick 15-second sample reel edit tailored for {biz_name} completely on the house.\n\n"
                f"Mind if I send over the sample preview for you to see?\n\n"
                f"Best regards,\n"
                f"{sender_name}\n"
                f"{agency_name}\n"
                + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                f"WhatsApp: {sender_phone}"
            )
        elif service_type == "graphic_design":
            subject = f"visual design concept for {biz_name}"
            body = (
                f"Hi there,\n\n"
                f"Was looking at {term} in {city} and came across {biz_name}, really impressed by your reputation.\n\n"
                f"One thing I noticed is that your social graphics and promotional visuals could look significantly more high-end and cohesive to match the premium quality of your service.\n\n"
                f"I designed a quick brand concept & social visual mockup for {biz_name} at no cost.\n\n"
                f"Would you be open to taking a quick look at the concept mockup?\n\n"
                f"Best regards,\n"
                f"{sender_name}\n"
                f"{agency_name}\n"
                + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                f"WhatsApp: {sender_phone}"
            )
        elif service_type == "social_media_ads":
            subject = f"client acquisition inquiry for {biz_name}"
            body = (
                f"Hi there,\n\n"
                f"Quick question for the management at {biz_name} in {city}.\n\n"
                f"Noticed several of your competitors in {city} are aggressively running Meta & Google ad campaigns to capture local high-ticket inquiries before clients even find your listing.\n\n"
                f"We set up direct booking ad funnels that consistently generate 15 to 30 qualified local inquiries every month on autopilot.\n\n"
                f"I put together a 2-minute breakdown of how this would look for {biz_name}. Would you be open to a quick look?\n\n"
                f"Best regards,\n"
                f"{sender_name}\n"
                f"{agency_name}\n"
                + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                f"WhatsApp: {sender_phone}"
            )
        elif service_type == "ai_chatbots":
            subject = f"24/7 AI booking assistant for {biz_name}"
            body = (
                f"Hi there,\n\n"
                f"Quick question for the team at {biz_name} in {city}.\n\n"
                f"I noticed that like most {term}, customer calls and inquiries after hours or during busy times often go unanswered—and clients usually call a competitor instead of leaving a voicemail.\n\n"
                f"We set up 24/7 AI Receptionists & WhatsApp booking bots that instantly respond to missed calls, answer customer FAQs, and lock in appointments directly onto your calendar.\n\n"
                f"I put together a quick 90-second interactive demo of how the AI bot would respond for {biz_name}. Mind if I send it over?\n\n"
                f"Best regards,\n"
                f"{sender_name}\n"
                f"{agency_name}\n"
                + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                f"WhatsApp: {sender_phone}"
            )
        elif service_type == "shopify_ecom":
            subject = f"recovering 20% lost revenue for {biz_name}"
            body = (
                f"Hi there,\n\n"
                f"Came across {biz_name} in {city}—really love your products and brand presentation!\n\n"
                f"One thing I noticed: like most e-commerce stores, over 65% of shoppers add items to cart but drop off before checkout. Without automated Klaviyo recovery flows, that revenue is lost permanently.\n\n"
                f"We build automated email flows that consistently recover 18% to 28% of abandoned checkouts on autopilot without spending an extra dollar on ads.\n\n"
                f"I put together a free 2-minute flow audit for {biz_name} showing the exact 3 emails to set up. Would you be open to taking a look?\n\n"
                f"Best regards,\n"
                f"{sender_name}\n"
                f"{agency_name}\n"
                + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                f"WhatsApp: {sender_phone}"
            )
        elif service_type == "google_reviews" or service_type == "seo_ranking":
            subject = f"5-star review booster for {biz_name} in {city}"
            body = (
                f"Hi there,\n\n"
                f"Was looking at {term} in {city} and saw {biz_name} with {rating_text}.\n\n"
                f"Your service is clearly top quality, but having fewer than 100+ public reviews on Google Maps makes it easy for competitors with more reviews to capture local customers.\n\n"
                f"We install smart NFC tap-cards and automated review boosters that make it effortless for happy clients to leave a 5-star Google review in under 10 seconds right from their phone.\n\n"
                f"I prepared a quick breakdown of how a similar business added 80+ five-star reviews in 30 days. Mind if I share the details?\n\n"
                f"Best regards,\n"
                f"{sender_name}\n"
                f"{agency_name}\n"
                + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                f"WhatsApp: {sender_phone}"
            )
        else: # web_design (default)
            if "Meta" in source:
                subject = f"website concept demo for {biz_name}'s ad campaigns"
                body = (
                    f"Hi there,\n\n"
                    f"Saw your active ads running in {city} for {biz_name} today, creative looks really good.\n\n"
                    f"One thing I noticed: your ads direct traffic straight to chat instead of an official website. When paying for ad clicks, not having a website to showcase your portfolio and transparent pricing usually means a lot of potential buyers drop off before reaching out.\n\n"
                    f"If you're interested, I can put together a free concept demo of how a custom website would look for {biz_name}, completely on the house.\n\n"
                    f"Let me know if that's something you'd like me to prepare for you.\n\n"
                    f"Best regards,\n"
                    f"{sender_name}\n"
                    f"{agency_name}\n"
                    + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                    f"WhatsApp: {sender_phone}"
                )
            elif "Instagram" in source or "Social" in source:
                subject = f"website concept demo for {biz_name} in {city}"
                body = (
                    f"Hi there,\n\n"
                    f"Came across your profile on Instagram while looking at {term} in {city}, and love the work you guys share.\n\n"
                    f"I noticed you do not currently have an official website linked in your bio for followers to browse your full services or book online.\n\n"
                    f"If you're interested, I'd be glad to put together a free concept demo of how a dedicated website would look for {biz_name}, at no cost.\n\n"
                    f"Let me know if you'd be open to seeing a demo concept.\n\n"
                    f"Best regards,\n"
                    f"{sender_name}\n"
                    f"{agency_name}\n"
                    + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                    f"WhatsApp: {sender_phone}"
                )
            elif "Google Ads" in source:
                subject = f"website concept demo for {biz_name}'s Google ads"
                body = (
                    f"Hi there,\n\n"
                    f"Saw your Google Search ad for {biz_name} in {city} while looking at {term}.\n\n"
                    f"Noticed your ad does not link to an official website. Since you are paying for search clicks, not having a dedicated website with your services and instant quote options usually means visitors bounce to competitors before reaching out.\n\n"
                    f"If you're interested, I can create a free concept demo of how a dedicated website would look for {biz_name}, completely on the house.\n\n"
                    f"Let me know if that's something you'd be open to exploring.\n\n"
                    f"Best regards,\n"
                    f"{sender_name}\n"
                    f"{agency_name}\n"
                    + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                    f"WhatsApp: {sender_phone}"
                )
            else: # Google Maps
                subject = f"website concept demo for {biz_name} in {city}"
                body = (
                    f"Hi there,\n\n"
                    f"Was looking at {term} around {city} today and came across {biz_name}, congrats on the {rating_text}.\n\n"
                    f"I noticed you do not currently have an official website linked to your Google listing to showcase your work and take direct client inquiries.\n\n"
                    f"If you're interested, I'd be happy to put together a free concept demo for {biz_name} so you can see how it would look first, no obligation at all.\n\n"
                    f"Let me know if that's something you'd like me to prepare for you.\n\n"
                    f"Best regards,\n"
                    f"{sender_name}\n"
                    f"{agency_name}\n"
                    + (f"Showcase: {portfolio_url}\n" if portfolio_url else "") +
                    f"WhatsApp: {sender_phone}"
                )

        return {"subject": subject, "body": body}

    @classmethod
    def generate_whatsapp_pitch(cls, lead: dict, sender_name: str = "Hamza", agency_name: str = "HRS Web Solution", sender_phone: str = "+91 8808129388", service_type: str = "web_design", portfolio_url: str = "") -> str:
        biz_name = lead.get("business_name", "your business").strip()
        city = lead.get("city", "").strip() or "your area"
        rating = lead.get("rating", 4.9)
        reviews = lead.get("reviews_count", 0)
        category = lead.get("category", "services").strip()
        source = lead.get("source", "Google Maps").strip()
        term = cls.get_term_for_category(category)
        rating_text = cls._format_rating_text(rating, reviews)

        lead_seed = sum(ord(c) for c in (biz_name + city))
        greetings = ["Hey,", "Hi,", "Hello,", "Hi there,"]
        greeting = greetings[lead_seed % len(greetings)]

        if service_type == "video_editing":
            v_reels = [
                f"{greeting} saw your profile for {biz_name} in {city} today, solid work!\n\nNoticed you guys share great content but aren't posting short-form reels to capture new local clients. Many local businesses are getting 10x more reach simply with dynamic captions and hook-based reels.\n\nI put together a quick 15-second sample reel edit tailored for {biz_name} completely on the house.\n\nMind if I send over the sample preview for you to see?",
                f"{greeting} quick question for the team at {biz_name}.\n\nSaw your work in {city}—really clean presentation! I noticed your videos could get significantly more engagement on Instagram & TikTok with modern viral pacing and captions.\n\nI created a free sample reel concept for {biz_name} so you can see how it looks. No cost at all.\n\nWould you be open to checking out the quick video sample?"
            ]
            return v_reels[lead_seed % len(v_reels)]
        elif service_type == "graphic_design":
            v_design = [
                f"{greeting} came across {biz_name} while looking at {term} in {city}, love the reputation you have!\n\nOne thing I noticed: your brand graphics and social posts could look significantly more high-end and cohesive to reflect the true quality of your service.\n\nI designed a quick visual brand concept & mockup for {biz_name} at no cost.\n\nWould you be open to taking a quick look at the concept mockup?",
                f"{greeting} hope your week is going great.\n\nCame across {biz_name} in {city} ({rating_text}). Really solid concept! I put together a quick free redesign concept of your visual branding to show how it can attract more premium clients.\n\nLet me know if you'd like me to send over the mockup."
            ]
            return v_design[lead_seed % len(v_design)]
        elif service_type == "social_media_ads":
            v_ads = [
                f"{greeting} quick question for the owner of {biz_name} in {city}.\n\nNoticed several competitors in your area are actively running Meta & Google ads to take the majority of local customer inquiries.\n\nWe build direct inquiry funnels that bring 15 to 30 qualified bookings every month on auto-pilot.\n\nI put together a 2-minute breakdown of how this would look for {biz_name}. Would you be open to seeing a quick demo?",
                f"{greeting} saw your listing for {biz_name} in {city} with {rating_text}.\n\nIf you're currently looking to take on more high-ticket clients this month, we set up automated local customer acquisition systems.\n\nMind if I share a quick 2-minute case study showing how we generated 20+ inquiries for a similar business in your niche?"
            ]
            return v_ads[lead_seed % len(v_ads)]
        elif service_type == "ai_chatbots":
            v_ai = [
                f"{greeting} quick question for the team at {biz_name} in {city}.\n\nNoticed that after-hours or when staff is busy, many new customer inquiries get missed and end up calling competitors.\n\nWe build 24/7 AI Receptionist & WhatsApp booking bots that instantly answer missed calls, answer customer FAQs, and book appointments onto your calendar.\n\nI set up a quick 1-minute interactive demo showing how the AI assistant answers for {biz_name}. Mind if I share the test link?",
                f"{greeting} hope your week is going great.\n\nSaw your listing for {biz_name} in {city} with {rating_text}. We recently built an AI-powered missed-call assistant that automatically follows up with callers via WhatsApp and schedules appointments on autopilot.\n\nWould you be open to seeing a 90-second interactive demo tailored for {biz_name}?"
            ]
            return v_ai[lead_seed % len(v_ai)]
        elif service_type == "shopify_ecom":
            v_ecom = [
                f"{greeting} came across {biz_name} today—love your products and brand presentation!\n\nNoticed you drive solid traffic, but like most e-com brands, over 65% of shoppers drop off after adding to cart. Without automated Klaviyo recovery flows, that revenue is lost forever.\n\nWe set up automated email flows that recover 18% to 28% of abandoned checkouts on pure autopilot without spending an extra dollar on ads.\n\nI put together a free 2-minute audit for {biz_name} showing the exact recovery emails you should use. Mind if I share it?",
                f"{greeting} quick question for the founder of {biz_name}.\n\nLove the store aesthetic! We help e-commerce brands turn abandoned carts into revenue through automated email flows and post-purchase funnels.\n\nWould you be open to checking out a quick 2-minute revenue recovery audit we put together for {biz_name}?"
            ]
            return v_ecom[lead_seed % len(v_ecom)]
        elif service_type == "google_reviews" or service_type == "seo_ranking":
            v_seo = [
                f"{greeting} saw your listing for {biz_name} in {city} with {rating_text}—great reputation!\n\nYour service is clearly top quality, but competitors with more public reviews often capture local clients simply because of higher review counts.\n\nWe set up smart NFC Google tap-cards and automated review boosters that get happy clients to leave a 5-star review in under 10 seconds right from their phone.\n\nI prepared a quick breakdown showing how a similar local business added 80+ five-star reviews in 30 days. Mind if I share the details?",
                f"{greeting} quick question for the team at {biz_name}.\n\nSaw your listing in {city}—great reviews! We set up automated Google review boosters and NFC tap-cards that help businesses jump from 20 reviews to 150+ five-star ratings rapidly.\n\nWould you be open to seeing a quick 1-minute breakdown of how it works for {biz_name}?"
            ]
            return v_seo[lead_seed % len(v_seo)]
        else: # web_design
            if "Meta" in source:
                v_meta = [
                    f"{greeting} saw your active ad for {biz_name} in {city} today, work looks super clean!\n\nNoticed the ads direct traffic straight to chat without an official website. Without a proper website to showcase your portfolio and transparent pricing, a lot of potential clients drop off before messaging.\n\nIf this is something you're interested in, I can put together a free concept demo of how a custom website would look for {biz_name}, completely on the house.\n\nLet me know if you'd like me to prepare that for you.",
                    f"{greeting} quick note regarding your ad for {biz_name} in {city}.\n\nCreative looks great! One thing I noticed is that the ad directs clicks into chat rather than a dedicated website. An official site usually helps convert significantly more ad traffic into bookings.\n\nIf you're interested, I can design a free demo concept for {biz_name} so you can see how it looks. If you like the concept, we can talk, otherwise no pressure at all.\n\nLet me know if you'd be open to seeing a free demo."
                ]
                msg = v_meta[lead_seed % len(v_meta)]
            elif "Instagram" in source or "Social" in source:
                v_social = [
                    f"{greeting} came across {biz_name} on Instagram while looking at {term} in {city}, love the work you guys share!\n\nNoticed your bio does not have an official website linked for clients to browse your full services or book online.\n\nIf you're interested, I'd be happy to put together a free concept demo of a custom website for {biz_name} at no cost.\n\nLet me know if you'd be open to seeing a demo concept for your business.",
                    f"{greeting} saw your profile for {biz_name} in {city}—solid work and presentation!\n\nI noticed you don't have a standalone website linked in your profile yet to showcase your full portfolio and take bookings.\n\nIf that's something you've considered, I can prepare a free demo concept tailored for {biz_name} so you can see how it looks.\n\nLet me know if you'd like me to put that together for you."
                ]
                msg = v_social[lead_seed % len(v_social)]
            elif "Google Ads" in source:
                v_gads = [
                    f"{greeting} saw your Google Search ad for {biz_name} in {city} today!\n\nNoticed your ad does not link to an official website. Since you are paying for clicks, people usually bounce back to search if they cannot see your full work or instant quote options.\n\nIf you're interested, I can create a free concept demo of how a dedicated website would look for {biz_name}, completely on the house.\n\nLet me know if that's something you'd be open to exploring.",
                    f"{greeting} came across your sponsored listing for {biz_name} in {city}.\n\nNoticed you are paying for search traffic without an official landing website. Having a dedicated site usually lowers your cost per lead significantly.\n\nIf you're interested, I can put together a free demo concept of your website so you can see how it looks first.\n\nLet me know if you'd like to see a demo."
                ]
                msg = v_gads[lead_seed % len(v_gads)]
            else: # Google Maps
                v_maps = [
                    f"{greeting} was looking at {term} around {city} and came across {biz_name}, love the {rating_text}!\n\nNoticed you do not have an official website linked on Google Maps yet to showcase your work and take direct inquiries.\n\nIf this is something you're interested in, I'd be happy to put together a free concept demo of how a custom website would look for {biz_name}, completely on the house.\n\nLet me know if you'd like me to prepare that for you.",
                    f"{greeting} quick question for the team at {biz_name}.\n\nSaw your listing on Google Maps in {city} with {rating_text}—great reputation!\n\nI noticed you do not have an official website connected to your listing though to showcase your work and capture direct client inquiries.\n\nIf you're interested, I can put together a free concept demo for {biz_name} so you can see how it would look first, no obligation at all.\n\nLet me know if that's something you'd be open to exploring.",
                    f"{greeting} hope your week is going great.\n\nCame across {biz_name} while searching for {term} in {city} ({rating_text}).\n\nNoticed your Google Maps profile is not linked to a standalone website. A dedicated website helps build credibility and convert map visitors into calls.\n\nIf you're interested, I can design a free concept demo for {biz_name} so you can take a look. No obligation at all.\n\nWould you be open to seeing a free demo concept?"
                ]
                msg = v_maps[lead_seed % len(v_maps)]

            return msg

    @classmethod
    def generate_pitches_with_ai(cls, lead: dict, api_key: str, sender_name: str = "Mohammad Hamza", agency_name: str = "HRS Web Solution", sender_email: str = "hrswebsolution@gmail.com", sender_phone: str = "+91 8808129388", model: str = "", provider: str = "gemini", custom_endpoint: str = "", service_type: str = "web_design", portfolio_url: str = "") -> dict:
        """
        Universal Multi-AI Engine supporting:
        - Google Gemini (Free tier)
        - Anthropic Claude (Claude 3.5 Sonnet / Haiku)
        - OpenAI ChatGPT (GPT-4o / GPT-4o-mini)
        - DeepSeek (V3 / R1)
        - Groq (Llama 3.3 70B / Llama 3.1 8B)
        - OpenRouter / Custom OpenAI-compatible endpoints
        """
        if not api_key or not api_key.strip():
            return cls._fallback_pitches(lead, sender_name, agency_name, sender_email, sender_phone, service_type, portfolio_url)

        biz_name = lead.get("business_name", "").strip()
        city = lead.get("city", "").strip()
        category = lead.get("category", "").strip()
        country = lead.get("country", "USA").strip()
        rating = lead.get("rating", 4.8)
        reviews = lead.get("reviews_count", 0)
        source = lead.get("source", "Google Maps").strip()

        service_context = {
            "web_design": "You are a web designer pitching a free custom website concept demo because they currently have NO official website or broken listing.",
            "video_editing": "You are a video editor pitching short-form reels/shorts with dynamic captions and viral hooks to help them 10x their social reach, offering a free 15-second sample reel.",
            "graphic_design": "You are a graphic designer pitching an upgrade to their brand visuals, menus, and social graphics to match their high quality, offering a free concept mockup.",
            "social_media_ads": "You are a performance marketer pitching an automated client acquisition system (Meta/Google ad funnels) that brings 15-30 qualified inquiries per month.",
            "ai_chatbots": "You are an AI automation specialist pitching a 24/7 AI Receptionist & WhatsApp booking bot to capture missed calls and book appointments automatically.",
            "shopify_ecom": "You are an e-commerce specialist pitching automated Klaviyo abandoned cart flows to recover 18-28% of lost checkouts on autopilot.",
            "google_reviews": "You are a local reputation specialist pitching automated Google review growth & NFC tap-cards to help them reach 150+ 5-star reviews rapidly."
        }.get(service_type, "You are a specialist pitching a free concept demo.")

        prompt = f"""You are an elite, natural human cold outreach specialist working with {sender_name} at {agency_name}.
Role: {service_context}

Target business:
- Business: {biz_name}
- Category: {category}
- City: {city}, Country: {country}
- Rating: {rating} stars ({reviews} reviews)
- Source: {source}

Write TWO messages:
1. "whatsapp_message": Under 70 words. Ultra-natural, human, casual tone. Mention their reviews/presence in {city}. Pitch your free concept demo/sample. Zero emojis, zero spam symbols (no asterisks or quotes), zero pushy sales talk. Sign off casually with just first name ({sender_name.split()[0]}).
2. "email_subject": Under 6 words, lowercase/natural style. E.g. "quick question {biz_name}"
3. "email_body": Under 85 words. Plain text, genuine, short paragraphs.

CRITICAL: Return ONLY valid raw JSON with keys: "whatsapp_message", "email_subject", "email_body". Do NOT wrap in markdown fences or backticks.
"""

        provider = (provider or "gemini").lower().strip()
        model_str = (model or "").strip()
        text_response = ""

        try:
            if provider == "gemini":
                target_model = model_str or "gemini-1.5-flash"
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{target_model}:generateContent?key={api_key.strip()}"
                payload = {
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": 0.7, "maxOutputTokens": 600}
                }
                req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=14) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    text_response = res_data["candidates"][0]["content"]["parts"][0]["text"].strip()

            elif provider == "claude":
                target_model = model_str or "claude-3-5-sonnet-20241022"
                url = "https://api.anthropic.com/v1/messages"
                payload = {
                    "model": target_model,
                    "max_tokens": 600,
                    "messages": [{"role": "user", "content": prompt}]
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "x-api-key": api_key.strip(),
                        "anthropic-version": "2023-06-01",
                        "Content-Type": "application/json"
                    }
                )
                with urllib.request.urlopen(req, timeout=14) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    text_response = res_data["content"][0]["text"].strip()

            elif provider == "openai":
                target_model = model_str or "gpt-4o"
                is_reasoning_model = target_model.startswith("o1") or target_model.startswith("o3")
                if is_reasoning_model:
                    messages = [{"role": "user", "content": f"You are an elite, natural cold outreach copywriter. Return ONLY valid JSON with keys 'whatsapp_message', 'email_subject', 'email_body'.\n\n{prompt}"}]
                else:
                    messages = [
                        {"role": "system", "content": "You are an elite, natural cold outreach copywriter. Return ONLY valid JSON."},
                        {"role": "user", "content": prompt}
                    ]
                payload = {
                    "model": target_model,
                    "messages": messages
                }
                if is_reasoning_model:
                    payload["max_completion_tokens"] = 800
                else:
                    payload["max_tokens"] = 600

                url = "https://api.openai.com/v1/chat/completions"
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "Authorization": f"Bearer {api_key.strip()}",
                        "Content-Type": "application/json"
                    }
                )
                with urllib.request.urlopen(req, timeout=14) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    text_response = res_data["choices"][0]["message"]["content"].strip()

            elif provider == "deepseek":
                target_model = model_str or "deepseek-chat"
                url = "https://api.deepseek.com/chat/completions"
                payload = {
                    "model": target_model,
                    "messages": [
                        {"role": "system", "content": "You are an elite, natural cold outreach copywriter. Return ONLY valid JSON."},
                        {"role": "user", "content": prompt}
                    ],
                    "max_tokens": 600
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "Authorization": f"Bearer {api_key.strip()}",
                        "Content-Type": "application/json"
                    }
                )
                with urllib.request.urlopen(req, timeout=14) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    text_response = res_data["choices"][0]["message"]["content"].strip()

            elif provider == "groq":
                target_model = model_str or "llama-3.3-70b-versatile"
                url = "https://api.groq.com/openai/v1/chat/completions"
                payload = {
                    "model": target_model,
                    "messages": [
                        {"role": "system", "content": "You are an elite, natural cold outreach copywriter. Return ONLY valid JSON."},
                        {"role": "user", "content": prompt}
                    ],
                    "max_tokens": 600
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "Authorization": f"Bearer {api_key.strip()}",
                        "Content-Type": "application/json"
                    }
                )
                with urllib.request.urlopen(req, timeout=14) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    text_response = res_data["choices"][0]["message"]["content"].strip()

            elif provider in ("openrouter", "custom"):
                target_model = model_str or "anthropic/claude-3.5-sonnet"
                url = custom_endpoint.strip() if custom_endpoint and custom_endpoint.strip() else "https://openrouter.ai/api/v1/chat/completions"
                payload = {
                    "model": target_model,
                    "messages": [
                        {"role": "system", "content": "You are an elite, natural cold outreach copywriter. Return ONLY valid JSON."},
                        {"role": "user", "content": prompt}
                    ],
                    "max_tokens": 600
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "Authorization": f"Bearer {api_key.strip()}",
                        "Content-Type": "application/json",
                        "HTTP-Referer": "https://arabiansshoppingzone.shop",
                        "X-Title": "Outreach Studio Pro"
                    }
                )
                with urllib.request.urlopen(req, timeout=14) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    text_response = res_data["choices"][0]["message"]["content"].strip()

            if text_response:
                clean_text = text_response.strip()
                if "```" in clean_text:
                    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", clean_text, re.DOTALL)
                    if match:
                        clean_text = match.group(1)
                    else:
                        clean_text = re.sub(r"^```(?:json)?\s*", "", clean_text)
                        clean_text = re.sub(r"\s*```$", "", clean_text)

                if not clean_text.startswith("{") and "{" in clean_text:
                    start_idx = clean_text.find("{")
                    end_idx = clean_text.rfind("}")
                    if start_idx != -1 and end_idx != -1:
                        clean_text = clean_text[start_idx:end_idx+1]

                parsed = json.loads(clean_text)
                wa_msg = parsed.get("whatsapp_message", "").strip()
                subj = parsed.get("email_subject", "").strip()
                body = parsed.get("email_body", "").strip()
                if wa_msg and subj and body:
                    return {
                        "email_subject": subj,
                        "email_body": body,
                        "whatsapp_message": wa_msg,
                        "ai_powered": True,
                        "provider": provider,
                        "model": model_str
                    }
        except Exception as e:
            print(f"[GlobalPitchEngine] {provider.upper()} AI notice: {e}. Using natural human template fallback.")

        return cls._fallback_pitches(lead, sender_name, agency_name, sender_email, sender_phone, service_type, portfolio_url)

    @classmethod
    def generate_pitches_with_gemini(cls, lead: dict, api_key: str, sender_name: str = "Mohammad Hamza", agency_name: str = "HRS Web Solution", sender_email: str = "hrswebsolution@gmail.com", sender_phone: str = "+91 8808129388", model: str = "gemini-1.5-flash", service_type: str = "web_design") -> dict:
        """Backward-compatible alias for generate_pitches_with_ai"""
        return cls.generate_pitches_with_ai(lead, api_key, sender_name, agency_name, sender_email, sender_phone, model, provider="gemini", service_type=service_type)

    @classmethod
    def _fallback_pitches(cls, lead: dict, sender_name: str, agency_name: str, sender_email: str, sender_phone: str, service_type: str = "web_design", portfolio_url: str = "") -> dict:
        email_data = cls.generate_email_pitch(lead, sender_name, agency_name, sender_email, sender_phone, service_type, portfolio_url)
        wa_data = cls.generate_whatsapp_pitch(lead, sender_name.split()[0] if sender_name else "Hamza", agency_name, sender_phone, service_type, portfolio_url)
        return {
            "email_subject": email_data["subject"],
            "email_body": email_data["body"],
            "whatsapp_message": wa_data,
            "ai_powered": False
        }

    @classmethod
    def generate_pitches(cls, lead: dict, sender_name: str = "Mohammad Hamza", agency_name: str = "HRS Web Solution", sender_email: str = "hrswebsolution@gmail.com", sender_phone: str = "+91 8808129388", api_key: str = "", model: str = "", provider: str = "gemini", custom_endpoint: str = "", service_type: str = "web_design", portfolio_url: str = "") -> dict:
        if api_key and api_key.strip():
            return cls.generate_pitches_with_ai(lead, api_key, sender_name, agency_name, sender_email, sender_phone, model, provider, custom_endpoint, service_type, portfolio_url)
        return cls._fallback_pitches(lead, sender_name, agency_name, sender_email, sender_phone, service_type, portfolio_url)

if __name__ == "__main__":
    test_lead = {
        "business_name": "Hardy's Transport Ltd",
        "city": "Doncaster, South Yorkshire",
        "rating": 4.9,
        "reviews_count": 28,
        "category": "Commercial Logistics & Transport Ltd",
        "country": "UK",
        "source": "Google Maps"
    }
    pitches = GlobalPitchEngine.generate_pitches(test_lead)
    print("=== EMAIL SUBJECT ===")
    print(pitches["email_subject"])
    print("\n=== EMAIL BODY ===")
    print(pitches["email_body"])
    print("\n=== WHATSAPP MESSAGE ===")
    print(pitches["whatsapp_message"])
