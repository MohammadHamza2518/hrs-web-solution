import os
import sys
import threading
import time
import json
from flask import Flask, render_template, request, jsonify, send_file
from crm_manager import CRMManager
from pitch_engine import GlobalPitchEngine
from scraper_intl import InternationalScraper
from email_sender import EmailSender

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

@app.after_request
def add_no_cache_headers(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    return response

crm = CRMManager()
email_sender = EmailSender()

# Global background states
scraper_state = {
    "is_running": False,
    "current_query": "",
    "logs": [],
    "leads_found": 0
}
scraper_instance = None
scraper_lock = threading.Lock()

whatsapp_state = {
    "is_running": False,
    "current_lead": "",
    "sent_count": 0,
    "total_target": 0,
    "logs": []
}

@app.route("/")
def index():
    return render_template("index.html")

# ==================== LEADS API ====================
@app.route("/api/leads", methods=["GET"])
def get_leads():
    country = request.args.get("country", "all")
    source = request.args.get("source", "all")
    status = request.args.get("status", "all")
    category = request.args.get("category", "all")
    sent_filter = request.args.get("sent_filter", "all")
    search = request.args.get("search", "")
    no_web_only = request.args.get("no_website_only", "false").lower() == "true"

    leads = crm.get_leads(
        country=country,
        source=source,
        status=status,
        category=category,
        search=search,
        no_website_only=no_web_only,
        sent_filter=sent_filter
    )
    return jsonify({"success": True, "leads": leads, "count": len(leads)})

@app.route("/api/leads/add", methods=["POST"])
def add_lead():
    data = request.json or {}
    biz_name = data.get("business_name", "").strip()
    if not biz_name:
        return jsonify({"success": False, "error": "Business name is required"}), 400

    # Auto-generate pitches if missing
    if not data.get("pitch_message") or not data.get("email_pitch"):
        ai_provider = crm.get_config("ai_provider", "gemini").strip()
        ai_api_key = crm.get_config("ai_api_key", "").strip() or crm.get_config("gemini_api_key", "").strip()
        ai_model = crm.get_config("ai_model", "").strip()
        ai_custom_endpoint = crm.get_config("ai_custom_endpoint", "").strip()

        pitches = GlobalPitchEngine.generate_pitches(
            data,
            sender_name=crm.get_config("sender_name", "Mohammad Hamza"),
            agency_name=crm.get_config("agency_name", "HRS Web Solution"),
            sender_email=crm.get_config("sender_email", "hrswebsolution@gmail.com"),
            sender_phone=crm.get_config("sender_phone", "+91 8808129388"),
            api_key=ai_api_key,
            model=ai_model,
            provider=ai_provider,
            custom_endpoint=ai_custom_endpoint
        )
        data["pitch_message"] = pitches["whatsapp_message"]
        data["email_pitch"] = f"Subject: {pitches['email_subject']}\n\n{pitches['email_body']}"

    saved = crm.add_lead(data)
    if saved:
        return jsonify({"success": True, "message": "Lead added successfully"})
    return jsonify({"success": False, "error": "Duplicate lead or phone already exists"})

@app.route("/api/leads/<int:lead_id>/mark-sent", methods=["POST"])
def mark_sent(lead_id):
    data = request.json or {}
    channel = data.get("channel", "whatsapp").lower()
    override = bool(data.get("override_limit", False))

    stats = crm.get_stats()
    if channel == "whatsapp":
        if stats["wa_limit_reached"] and not override:
            return jsonify({
                "success": False,
                "limit_reached": True,
                "channel": "whatsapp",
                "message": f"Daily Safe WhatsApp Limit ({stats['daily_wa_limit']}) reached! To protect your WhatsApp (+91 8808129388) from permanent bans, stop outreach for today.",
                "stats": stats
            }), 429
        crm.mark_whatsapp_sent(lead_id)
    else:
        if stats["email_limit_reached"] and not override:
            return jsonify({
                "success": False,
                "limit_reached": True,
                "channel": "email",
                "message": f"Daily Safe Email Limit ({stats['daily_email_limit']}) reached! To protect domain deliverability, resume tomorrow.",
                "stats": stats
            }), 429
        crm.mark_email_sent(lead_id)

    updated_lead = crm.get_lead_by_id(lead_id)
    updated_stats = crm.get_stats()
    return jsonify({
        "success": True,
        "lead": updated_lead,
        "stats": updated_stats,
        "message": f"Marked as sent via {channel.title()}"
    })

@app.route("/api/leads/<int:lead_id>/status", methods=["POST"])
def update_status(lead_id):
    data = request.json or {}
    new_status = data.get("status", "NEW")
    crm.update_lead_status(lead_id, new_status)
    return jsonify({"success": True, "message": f"Status updated to {new_status}"})

@app.route("/api/leads/<int:lead_id>/pitch", methods=["POST"])
def update_pitch(lead_id):
    data = request.json or {}
    wa_pitch = data.get("pitch_message")
    email_pitch = data.get("email_pitch")
    crm.update_lead_pitches(lead_id, wa_pitch, email_pitch)
    return jsonify({"success": True, "message": "Pitch updated successfully"})

@app.route("/api/leads/<int:lead_id>/contact", methods=["POST"])
def update_contact(lead_id):
    data = request.json or {}
    crm.update_lead_contact(
        lead_id,
        phone=data.get("phone"),
        email=data.get("email"),
        notes=data.get("notes")
    )
    return jsonify({"success": True, "message": "Contact info updated"})

@app.route("/api/leads/<int:lead_id>", methods=["DELETE"])
def delete_lead(lead_id):
    crm.delete_lead(lead_id)
    return jsonify({"success": True, "message": "Lead deleted"})

@app.route("/api/leads/<int:lead_id>/generate-fresh-pitch", methods=["POST"])
def generate_fresh_pitch(lead_id):
    lead = crm.get_lead_by_id(lead_id)
    if not lead:
        return jsonify({"success": False, "error": "Lead not found"}), 404

    sender_name = crm.get_config("sender_name", "Mohammad Hamza")
    agency_name = crm.get_config("agency_name", "HRS Web Solution")
    sender_email = crm.get_config("sender_email", "hrswebsolution@gmail.com")
    sender_phone = crm.get_config("sender_phone", "+91 8808129388")
    ai_provider = crm.get_config("ai_provider", "gemini").strip()
    ai_api_key = crm.get_config("ai_api_key", "").strip() or crm.get_config("gemini_api_key", "").strip()
    ai_model = crm.get_config("ai_model", "").strip()
    ai_custom_endpoint = crm.get_config("ai_custom_endpoint", "").strip()
    portfolio_url = crm.get_config("portfolio_url", "").strip()
    service_type = lead.get("service_type") or crm.get_config("default_service_type", "web_design")

    pitches = GlobalPitchEngine.generate_pitches(
        lead,
        sender_name=sender_name,
        agency_name=agency_name,
        sender_email=sender_email,
        sender_phone=sender_phone,
        portfolio_url=portfolio_url,
        api_key=ai_api_key,
        model=ai_model,
        provider=ai_provider,
        custom_endpoint=ai_custom_endpoint,
        service_type=service_type
    )
    formatted_email = f"Subject: {pitches['email_subject']}\n\n{pitches['email_body']}"

    crm.update_lead_pitches(lead_id, pitches["whatsapp_message"], formatted_email)
    return jsonify({
        "success": True,
        "whatsapp_message": pitches["whatsapp_message"],
        "email_subject": pitches["email_subject"],
        "email_body": pitches["email_body"],
        "full_email_pitch": formatted_email,
        "ai_powered": pitches.get("ai_powered", False)
    })

# ==================== UNIVERSAL AI KEY TEST API ====================
@app.route("/api/ai/test-key", methods=["POST"])
def test_ai_key():
    import urllib.request
    import urllib.error
    data = request.json or {}
    provider = data.get("provider", "gemini").lower().strip()
    api_key = data.get("api_key", "").strip()
    model = data.get("model", "").strip()
    custom_endpoint = data.get("custom_endpoint", "").strip()

    if not api_key:
        return jsonify({"success": False, "error": "API Key cannot be blank"}), 400

    provider_names = {
        "gemini": "Google Gemini",
        "claude": "Anthropic Claude",
        "openai": "OpenAI (ChatGPT)",
        "deepseek": "DeepSeek AI",
        "groq": "Groq Fast Cloud",
        "openrouter": "OpenRouter / Custom API"
    }
    p_name = provider_names.get(provider, provider.title())

    try:
        if provider == "gemini":
            target_model = model or "gemini-1.5-flash"
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{target_model}:generateContent?key={api_key}"
            payload = {
                "contents": [{"parts": [{"text": "Reply with 'OK'"}]}],
                "generationConfig": {"maxOutputTokens": 10}
            }
            req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return jsonify({"success": True, "message": f"Verified! {p_name} ({target_model}) connected successfully."})

        elif provider == "claude":
            target_model = model or "claude-3-5-haiku-20241022"
            url = "https://api.anthropic.com/v1/messages"
            payload = {
                "model": target_model,
                "max_tokens": 10,
                "messages": [{"role": "user", "content": "Reply with 'OK'"}]
            }
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json"
                }
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return jsonify({"success": True, "message": f"Verified! {p_name} ({target_model}) connected successfully."})

        elif provider == "openai":
            target_model = model or "gpt-4o"
            is_reasoning_model = target_model.startswith("o1") or target_model.startswith("o3")
            url = "https://api.openai.com/v1/chat/completions"
            payload = {
                "model": target_model,
                "messages": [{"role": "user", "content": "Hi"}]
            }
            if is_reasoning_model:
                payload["max_completion_tokens"] = 10
            else:
                payload["max_tokens"] = 5
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return jsonify({"success": True, "message": f"Verified! {p_name} ({target_model}) connected successfully."})

        elif provider == "deepseek":
            target_model = model or "deepseek-chat"
            url = "https://api.deepseek.com/chat/completions"
            payload = {
                "model": target_model,
                "messages": [{"role": "user", "content": "Hi"}],
                "max_tokens": 5
            }
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return jsonify({"success": True, "message": f"Verified! {p_name} ({target_model}) connected successfully."})

        elif provider == "groq":
            target_model = model or "llama-3.1-8b-instant"
            url = "https://api.groq.com/openai/v1/chat/completions"
            payload = {
                "model": target_model,
                "messages": [{"role": "user", "content": "Hi"}],
                "max_tokens": 5
            }
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return jsonify({"success": True, "message": f"Verified! {p_name} ({target_model}) connected successfully."})

        elif provider in ("openrouter", "custom"):
            target_model = model or "meta-llama/llama-3.1-8b-instruct"
            url = custom_endpoint.strip() if custom_endpoint and custom_endpoint.strip() else "https://openrouter.ai/api/v1/chat/completions"
            payload = {
                "model": target_model,
                "messages": [{"role": "user", "content": "Hi"}],
                "max_tokens": 5
            }
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://arabiansshoppingzone.shop",
                    "X-Title": "Outreach Studio Pro"
                }
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return jsonify({"success": True, "message": f"Verified! {p_name} ({target_model}) connected successfully."})

        else:
            return jsonify({"success": False, "error": f"Unsupported provider '{provider}'"}), 400

    except urllib.error.HTTPError as e:
        err_msg = f"{p_name} API rejected connection (HTTP {e.code}). Please verify your API key."
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            if "error" in err_body:
                if isinstance(err_body["error"], dict) and "message" in err_body["error"]:
                    err_msg = err_body["error"]["message"]
                elif isinstance(err_body["error"], str):
                    err_msg = err_body["error"]
            elif "message" in err_body:
                err_msg = err_body["message"]
        except Exception:
            pass
        return jsonify({"success": False, "error": err_msg}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"Connection error: {str(e)}"}), 500

# ==================== STATS & CONFIG ====================
@app.route("/api/stats", methods=["GET"])
def get_stats():
    stats = crm.get_stats()
    return jsonify({"success": True, "stats": stats})

@app.route("/api/config", methods=["GET", "POST"])
def handle_config():
    if request.method == "POST":
        data = request.json or {}
        for k, v in data.items():
            crm.set_config(k, str(v).strip())
        return jsonify({"success": True, "message": "Settings saved successfully"})
    else:
        cfg = crm.get_all_config()
        if "is_onboarded" not in cfg:
            cfg["is_onboarded"] = "false"
        return jsonify({"success": True, "config": cfg})

# ==================== CLIENT ONBOARDING GATEKEEPER API ====================
@app.route("/api/onboarding/complete", methods=["POST"])
def complete_onboarding():
    data = request.json or {}
    sender_name = data.get("sender_name", "").strip() or "Mohammad Hamza"
    sender_email = data.get("sender_email", "").strip() or "hrswebsolution@gmail.com"
    sender_phone = data.get("sender_phone", "").strip() or "+91 8808129388"
    agency_name = data.get("agency_name", "").strip() or "HRS Web Solutions"
    agency_niche = data.get("agency_niche", "web_design").strip()
    portfolio_url = data.get("portfolio_url", "").strip()
    ai_provider = data.get("ai_provider", "gemini").strip()
    ai_model = data.get("ai_model", "gemini-1.5-flash").strip()
    ai_api_key = data.get("ai_api_key", "").strip()
    custom_endpoint = data.get("custom_endpoint", "").strip()

    # Save to persistent SQLite config
    crm.set_config("sender_name", sender_name)
    crm.set_config("sender_email", sender_email)
    crm.set_config("sender_phone", sender_phone)
    crm.set_config("agency_name", agency_name)
    crm.set_config("agency_niche", agency_niche)
    crm.set_config("portfolio_url", portfolio_url)
    crm.set_config("ai_provider", ai_provider)
    crm.set_config("ai_model", ai_model)
    crm.set_config("ai_api_key", ai_api_key)
    crm.set_config("gemini_api_key", ai_api_key if ai_provider == "gemini" else "")
    crm.set_config("ai_custom_endpoint", custom_endpoint)
    crm.set_config("daily_wa_limit", "50")
    crm.set_config("daily_email_limit", "100")
    crm.set_config("is_onboarded", "true")

    # Personalize all existing leads with the client's agency branding & contacts
    leads = crm.get_leads()
    updated_count = 0
    for lead in leads:
        try:
            lead_id = lead["id"]
            pitches = GlobalPitchEngine.generate_pitches(
                lead=lead,
                sender_name=sender_name,
                agency_name=agency_name,
                sender_email=sender_email,
                sender_phone=sender_phone,
                portfolio_url=portfolio_url,
                api_key=ai_api_key if ai_provider != "templates" else "",
                model=ai_model,
                provider=ai_provider,
                custom_endpoint=custom_endpoint,
                service_type=agency_niche
            )
            formatted_email = f"Subject: {pitches['email_subject']}\n\n{pitches['email_body']}"
            crm.update_lead_pitches(lead_id, pitches["whatsapp_message"], formatted_email)
            updated_count += 1
        except Exception as e:
            print(f"Error personalizing lead {lead.get('id')}: {e}")

    return jsonify({
        "success": True,
        "message": f"Studio Activated! {updated_count} leads successfully personalized with your identity.",
        "leads_updated": updated_count
    })

@app.route("/api/onboarding/reset", methods=["POST"])
def reset_onboarding():
    crm.set_config("is_onboarded", "false")
    return jsonify({"success": True, "message": "Onboarding reset. Welcome setup will appear on next visit."})

# ==================== SCRAPER BACKGROUND API ====================
@app.route("/api/scrape/start", methods=["POST"])
def start_scrape():
    global scraper_instance
    with scraper_lock:
        if scraper_state["is_running"]:
            return jsonify({"success": False, "error": "A scraping task is already running!"}), 400

        data = request.json or {}
        query = data.get("query", "").strip()
        max_leads = int(data.get("max_leads", 15))
        no_web_only = data.get("no_website_only", True)
        service_type = data.get("service_type", "web_design").strip()

        if not query:
            return jsonify({"success": False, "error": "Search query is required"}), 400

        scraper_state["is_running"] = True
        scraper_state["current_query"] = query
        scraper_state["logs"] = [f"🚀 Initializing search for: '{query}' ({max_leads} leads max) | Service: {service_type}..."]
        scraper_state["leads_found"] = 0

        def log_cb(msg):
            scraper_state["logs"].append(msg)
            # keep last 100 logs
            if len(scraper_state["logs"]) > 100:
                scraper_state["logs"].pop(0)

        def run_task():
            global scraper_instance
            try:
                scraper_instance = InternationalScraper(headless=True)
                results = scraper_instance.scrape(query, max_leads=max_leads, no_website_only=no_web_only, log_callback=log_cb, service_type=service_type)
                scraper_state["leads_found"] = len(results)
                log_cb(f"🎉 Scraping completed! {len(results)} new leads added to CRM.")
            except Exception as e:
                log_cb(f"❌ Error during scrape: {e}")
            finally:
                scraper_state["is_running"] = False

        thread = threading.Thread(target=run_task, daemon=True)
        thread.start()

        return jsonify({"success": True, "message": f"Scraping started for: {query}"})

@app.route("/api/scrape/status", methods=["GET"])
def scrape_status():
    return jsonify(scraper_state)

@app.route("/api/scrape/stop", methods=["POST"])
def stop_scrape():
    global scraper_instance
    if scraper_instance and scraper_state["is_running"]:
        scraper_instance.is_running = False
        scraper_state["is_running"] = False
        scraper_state["logs"].append("🛑 Scrape task aborted by user.")
        return jsonify({"success": True, "message": "Scraper stopped."})
    return jsonify({"success": False, "message": "Scraper was not running."})

# ==================== EMAIL SENDING API ====================
@app.route("/api/email/test-smtp", methods=["POST"])
def test_smtp():
    data = request.json or {}
    if data:
        # Save temp if passed
        for k in ["smtp_host", "smtp_port", "sender_email", "sender_password"]:
            if k in data:
                crm.set_config(k, str(data[k]).strip())
    res = email_sender.test_smtp_connection()
    return jsonify(res)

@app.route("/api/email/send-direct", methods=["POST"])
def send_email_direct():
    data = request.json or {}
    lead_id = data.get("lead_id")
    recipient = data.get("recipient_email", "").strip()
    subject = data.get("subject", "").strip()
    body = data.get("body", "").strip()

    if not recipient or not subject or not body:
        return jsonify({"success": False, "error": "Missing recipient, subject, or body"}), 400

    stats = crm.get_stats()
    if stats["email_limit_reached"] and not data.get("override_limit", False):
        return jsonify({
            "success": False,
            "limit_reached": True,
            "channel": "email",
            "error": f"Daily Safe Email Limit ({stats['daily_email_limit']}) reached! To protect domain deliverability, resume tomorrow or confirm override."
        }), 429

    res = email_sender.send_email(recipient, subject, body)
    if res.get("success") and lead_id:
        crm.mark_email_sent(lead_id)
        crm.update_lead_contact(lead_id, email=recipient)

    return jsonify(res)

# ==================== EXPORT API ====================
@app.route("/api/export/excel", methods=["GET"])
def export_excel():
    excel_path = crm.export_to_excel()
    return send_file(excel_path, as_attachment=True, download_name="Global_Leads_CRM.xlsx")

@app.route("/api/backup/download", methods=["GET"])
def download_backup():
    crm.save_backup()
    backup_file = crm.get_backup_path()
    today_str = time.strftime("%Y%m%d")
    return send_file(backup_file, as_attachment=True, download_name=f"CRM_Full_Data_Backup_{today_str}.json")

if __name__ == "__main__":
    import socket
    import webbrowser
    from werkzeug.serving import make_server

    port = int(os.environ.get("PORT", 5050))
    is_cloud = bool(os.environ.get("RENDER") or os.environ.get("RAILWAY_ENVIRONMENT") or os.environ.get("HEROKU"))

    print("\n" + "="*60)
    print("🌍 GLOBAL CLIENT OUTREACH STUDIO IS STARTING...")
    print(f"📍 Listening on Port: {port} | Cloud Mode: {is_cloud}")
    print(f"📍 Local URL: http://localhost:{port}")
    print("="*60 + "\n")

    def open_browser():
        if is_cloud:
            return
        time.sleep(1.0)
        try:
            webbrowser.open(f"http://localhost:{port}")
        except Exception:
            pass

    if not is_cloud:
        threading.Thread(target=open_browser, daemon=True).start()

    # Enable dual-stack IPv6+IPv4 so localhost resolves seamlessly on Windows
    try:
        sock = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        sock.bind(('::', port))
        sock.listen(128)
        srv = make_server('::', port, app, fd=sock.fileno(), threaded=True)
        srv.serve_forever()
    except Exception as e:
        app.run(host="0.0.0.0", port=port, debug=False)

