import sqlite3
import datetime
import time
import random
import sys
from config import DB_PATH

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

class SafetyGuard:
    """
    Foolproof Anti-Ban Shield for WhatsApp Outreach.
    Enforces automatic warm-up schedule, daily limits, business hours,
    and mandatory human cooling delays so the user CANNOT break rules.
    """
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self._init_safety_table()

    def _init_safety_table(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS system_metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            # Record start date if not already recorded
            cursor.execute("SELECT value FROM system_metadata WHERE key = 'first_outreach_date'")
            if not cursor.fetchone():
                today_str = datetime.date.today().isoformat()
                cursor.execute("INSERT INTO system_metadata (key, value) VALUES ('first_outreach_date', ?)", (today_str,))
            conn.commit()

    def get_campaign_day(self) -> int:
        """Returns which day of the campaign you are on (Day 1, Day 2, etc.)"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM system_metadata WHERE key = 'first_outreach_date'")
            row = cursor.fetchone()
            if not row:
                return 1
            first_date = datetime.date.fromisoformat(row[0])
            today = datetime.date.today()
            return max(1, (today - first_date).days + 1)

    def get_daily_limit(self) -> int:
        """
        Daily WhatsApp limit configured by user (default 50).
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM outreach_config WHERE key = 'daily_wa_limit'")
            row = cursor.fetchone()
            if row:
                try:
                    val = int(row[0])
                    return max(5, val)
                except Exception:
                    pass
        return 50

    def get_today_sent_count(self) -> int:
        """Counts how many WhatsApp messages have actually been sent today."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COUNT(*) FROM leads 
                WHERE (status IN ('MESSAGE_SENT', 'PITCHED_WHATSAPP', 'PITCHED_BOTH') OR sent_at IS NOT NULL)
                AND sent_at IS NOT NULL
                AND DATE(sent_at) = DATE('now', 'localtime')
            """)
            count = cursor.fetchone()[0]
            return count

    def is_business_hours(self) -> tuple[bool, str]:
        """
        Checks if current time is within safe local business hours (10:00 AM - 8:30 PM).
        Sending business pitches late at night increases spam report rate significantly.
        """
        now = datetime.datetime.now().time()
        start = datetime.time(10, 0)
        end = datetime.time(20, 30)

        if start <= now <= end:
            return True, "Within safe business hours (10:00 AM - 8:30 PM)."
        return False, f"Current time ({now.strftime('%I:%M %p')}) is outside business hours (10:00 AM - 8:30 PM). Sending now will get you reported!"

    def can_send_next_message(self, bypass_hours: bool = False) -> tuple[bool, str]:
        """
        Master safety validation check before sending any message.
        """
        # 1. Business hours check
        if not bypass_hours:
            allowed_hours, hours_msg = self.is_business_hours()
            if not allowed_hours:
                return False, f"⛔ [TIMING BLOCKED] {hours_msg}"

        # 2. Daily limit check
        sent_today = self.get_today_sent_count()
        limit = self.get_daily_limit()
        day = self.get_campaign_day()

        if sent_today >= limit:
            return False, (
                f"🛑 [DAILY QUOTA REACHED] You have sent {sent_today}/{limit} messages today (Campaign Day {day}).\n"
                f"   To protect your WhatsApp account from getting banned, the system is hard-locked until tomorrow!"
            )

        remaining = limit - sent_today
        return True, f"✅ Safe to send! (Sent today: {sent_today}/{limit} | Remaining quota: {remaining} | Campaign Day: {day})"

    @staticmethod
    def human_cooldown(min_s: int = 45, max_s: int = 75):
        """Forces an anti-ban randomized human delay with a live countdown timer (minimum 45 seconds)."""
        delay = random.randint(max(45, min_s), max(45, max_s))
        print(f"\n🛡️ [Safety Shield] Applying mandatory human cooldown of {delay} seconds (anti-ban)...")
        for remaining in range(delay, 0, -1):
            sys.stdout.write(f"\r⏳ Anti-Ban Protection: Cooling down... {remaining:02d}s remaining ")
            sys.stdout.flush()
            time.sleep(1)
        print("\r✅ Cooldown complete. Safe to send next message.                      \n")

if __name__ == "__main__":
    guard = SafetyGuard()
    allowed, status_msg = guard.can_send_next_message(bypass_hours=True)
    print("--- SAFETY GUARD STATUS ---")
    print("Campaign Day:", guard.get_campaign_day())
    print("Daily Limit:", guard.get_daily_limit())
    print("Sent Today:", guard.get_today_sent_count())
    print("Status:", status_msg)
